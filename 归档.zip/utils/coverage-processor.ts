import * as fs from 'fs';
import * as path from 'path';
import * as xml2js from 'xml2js';
import * as csv from 'csv-parse/sync';

type CoverageType = 'cobertura' | 'lcov' | 'jacoco';

class CoverageProcessor {

    constructor(
        private file_path: string,
        private src_file_path: string,
        private coverage_type: CoverageType,
        private use_report_coverage_feature_flag: boolean = false
    ) {
    }

    public process_coverage_report(time_of_test_command: number): [number[], number[], number] {
        this.verify_report_update(time_of_test_command);
        return this.parse_coverage_report();
    }

    private verify_report_update(time_of_test_command: number): void {
        if (!fs.existsSync(this.file_path)) {
            throw new Error(`Fatal: Coverage report "${this.file_path}" was not generated.`);
        }

        const file_mod_time_ms = Math.round(fs.statSync(this.file_path).mtimeMs);

        if (file_mod_time_ms <= time_of_test_command) {
            throw new Error(`Fatal: The coverage report file was not updated after the test command. file_mod_time_ms: ${file_mod_time_ms}, time_of_test_command: ${time_of_test_command}.`);
        }
    }

    private parse_coverage_report(): [number[], number[], number] {
        if (this.use_report_coverage_feature_flag) {
            switch (this.coverage_type) {
                case 'cobertura':
                    return this.parse_coverage_report_cobertura();
                case 'lcov':
                    return this.parse_coverage_report_lcov();
                case 'jacoco':
                    return this.parse_coverage_report_jacoco();
                default:
                    throw new Error(`Unsupported coverage report type: ${this.coverage_type}`);
            }
        } else {
            switch (this.coverage_type) {
                case 'cobertura':
                    return this.parse_coverage_report_cobertura(path.basename(this.src_file_path));
                case 'lcov':
                    return this.parse_coverage_report_lcov();
                case 'jacoco':
                    return this.parse_coverage_report_jacoco();
                default:
                    throw new Error(`Unsupported coverage report type: ${this.coverage_type}`);
            }
        }
    }

    private parse_coverage_report_cobertura(filename?: string): [number[], number[], number] {
        const xmlData = fs.readFileSync(this.file_path, 'utf-8');
        let result: any;
        xml2js.parseString(xmlData, (err, parsed) => {
            if (err) {
                throw err;
            }
            result = parsed;
        });

        if (filename) {
            for (const cls of result.coverage.packages[0].package[0].classes[0].class) {
                if (cls.$.filename.endsWith(filename)) {
                    return this.parse_coverage_data_for_class(cls);
                }
            }
            return [[], [], 0];
        } else {
            const coverage_data: { [key: string]: [number[], number[], number] } = {};
            for (const cls of result.coverage.packages[0].package[0].classes[0].class) {
                coverage_data[cls.$.filename] = this.parse_coverage_data_for_class(cls);
            }
            return Object.values(coverage_data)[0] || [[], [], 0];
        }
    }

    private parse_coverage_data_for_class(cls: any): [number[], number[], number] {
        const lines_covered: number[] = [];
        const lines_missed: number[] = [];

        for (const line of cls.lines[0].line) {
            const line_number = parseInt(line.$.number);
            const hits = parseInt(line.$.hits);
            if (hits > 0) {
                lines_covered.push(line_number);
            } else {
                lines_missed.push(line_number);
            }
        }

        const total_lines = lines_covered.length + lines_missed.length;
        const coverage_percentage = total_lines > 0 ? lines_covered.length / total_lines : 0;

        return [lines_covered, lines_missed, coverage_percentage];
    }

    private parse_coverage_report_lcov(): [number[], number[], number] {
        const lines_covered: number[] = [];
        const lines_missed: number[] = [];
        const filename = path.basename(this.src_file_path);

        try {
            const fileContent = fs.readFileSync(this.file_path, 'utf-8');
            const lines = fileContent.split('\n');

            let isTargetFile = false;
            for (const line of lines) {
                const trimmedLine = line.trim();
                if (trimmedLine.startsWith('SF:')) {
                    isTargetFile = trimmedLine.endsWith(filename);
                } else if (isTargetFile) {
                    if (trimmedLine.startsWith('DA:')) {
                        const [lineNumber, hits] = trimmedLine.replace('DA:', '').split(',').map(Number);
                        if (hits > 0) {
                            lines_covered.push(lineNumber);
                        } else {
                            lines_missed.push(lineNumber);
                        }
                    } else if (trimmedLine.startsWith('end_of_record')) {
                        break;
                    }
                }
            }
        } catch (e) {
            console.error(`Error reading file ${this.file_path}: ${e}`);
            throw e;
        }

        const total_lines = lines_covered.length + lines_missed.length;
        const coverage_percentage = total_lines > 0 ? lines_covered.length / total_lines : 0;

        return [lines_covered, lines_missed, coverage_percentage];
    }

    private parse_coverage_report_jacoco(): [number[], number[], number] {
        const [package_name, class_name] = this.extract_package_and_class_java();
        const [missed, covered] = this.parse_missed_covered_lines_jacoco(package_name, class_name);

        const total_lines = missed + covered;
        const coverage_percentage = total_lines > 0 ? covered / total_lines : 0;

        return [[], [], coverage_percentage];
    }

    private parse_missed_covered_lines_jacoco(package_name: string, class_name: string): [number, number] {
        const fileContent = fs.readFileSync(this.file_path, 'utf-8');
        const records = csv.parse(fileContent, { columns: true });

        for (const row of records) {
            if (row.PACKAGE === package_name && row.CLASS === class_name) {
                try {
                    const missed = parseInt(row.LINE_MISSED);
                    const covered = parseInt(row.LINE_COVERED);
                    return [missed, covered];
                } catch (e) {
                    console.error(`Missing expected column in CSV: ${e}`);
                    throw e;
                }
            }
        }

        return [0, 0];
    }

    private extract_package_and_class_java(): [string, string] {
        const fileContent = fs.readFileSync(this.src_file_path, 'utf-8');
        const lines = fileContent.split('\n');

        const package_pattern = /^\s*package\s+([\w\.]+)\s*;.*$/;
        const class_pattern = /^\s*public\s+class\s+(\w+).*/;

        let package_name = '';
        let class_name = '';

        for (const line of lines) {
            if (!package_name) {
                const package_match = line.match(package_pattern);
                if (package_match) {
                    package_name = package_match[1];
                }
            }

            if (!class_name) {
                const class_match = line.match(class_pattern);
                if (class_match) {
                    class_name = class_match[1];
                }
            }

            if (package_name && class_name) {
                break;
            }
        }

        return [package_name, class_name];
    }
}

export { CoverageProcessor, CoverageType };