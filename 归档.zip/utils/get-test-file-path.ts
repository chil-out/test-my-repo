
import { fileExists } from '../helpers/file-exists';

export const getTestFilePath = async (filePath: string | undefined) => {
    if (!filePath) return undefined;

    const fileExtension = filePath.split('.').pop();
    const testFileExtension =
      fileExtension && ['jsx', 'tsx'].includes(fileExtension as string)
        ? fileExtension.replace('x', '')
        : fileExtension;

    const createReplacementFilePath = (
      path: string,
      ext: string,
      replacement: string
    ) => {
      return path.replace(
        new RegExp('\\.' + ext + '$'),
        replacement
      );
    };

    const testFile = createReplacementFilePath(
      filePath,
      fileExtension!,
      `.test.${testFileExtension}`
    );
    const specFile = createReplacementFilePath(
      filePath,
      fileExtension!,
      `.spec.${testFileExtension}`
    );

    if (await fileExists(testFile)) {
      return testFile;
    } else if (await fileExists(specFile)) {
      return specFile;
    }
    return undefined;
  };