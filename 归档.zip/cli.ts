import { cli } from 'cleye';
import { red } from 'kolorist';
import { version } from '../package.json';
import config from './commands/config';
import update from './commands/update';
import { commandName } from './helpers/constants';
import { handleCliError } from './helpers/error';
import { RunOptions, runAll } from './helpers/run';
import { interactiveMode } from './helpers/interactive-mode';
import { outro } from '@clack/prompts';
import { isValidProject } from './helpers/validate-project';
import { invalidProjectWarningMessage } from './helpers/invalid-project-warning';
import { getTestFilePath } from './utils/get-test-file-path';
import { copyFileSync } from 'node:fs';

// Suppress punnycode warnings
const originalEmit = process.emitWarning;
process.emitWarning = function (...args) {
  const [warning] = args;
  const warningString = warning.toString();
  // Ignore annoying "punnycode is deprecated" warning that comes
  // from one of our dependencies
  if (warningString.includes('punnycode')) return;
  return originalEmit.apply(process, args as any);
};

cli(
  {
    name: commandName,
    version,
    parameters: ['[file path]'],
    flags: {
      testFilepath: {
        type: String,
        description: 'The test file path',
        alias: 'f',
      },
      testFileOutputPath: {
        type: String,
        description: 'The test file output path',
        alias: 'o',
      },
      coverageReportPath: {
        type: String,
        description: 'The coverage report path',
        alias: 'c',
      },
      testCommand: {
        type: String,
        description: 'The test command to run',
        alias: 't',
      },
      testCommandDirectory: {
        type: String,
        description: 'The test command directory',
        alias: 'd',
      },
      includedFiles: {
        type: Array,
        description: 'The files to include in the test',
        alias: 'i',
      },
      coverageType: {
        type: String,
        description: 'The type of coverage to generate',
        alias: 'v',
      },
      reportFilepath: {
        type: String,
        description: 'The report file path',
        alias: 'r',
      },
      desiredCoverage: {
        type: Number,
        description: 'The desired coverage',
        alias: 'e',
        default: 90,
      },
      maxRuns: {
        type: Number,
        description: 'The maximum number of runs to attempt',
        alias: 'm',
      },
      thread: { type: String, description: 'Thread ID to resume' },
      additionalInstructions: {
        type: String,
        description: 'Additional instructions for the LLM',
        alias: 'a',
      },
    },
    commands: [config, update],
  },
  async (argv) => {
    const filePath = argv._.filePath; //测试文件路径

    const testFilePath =
      argv.flags.testFilepath || (await getTestFilePath(filePath)) || ''; //测试文件路径，如果没有制定，自己找，找不到返回空

    const runOptions: RunOptions = {
      outputFile: filePath!,
      testCommand: argv.flags.testCommand || '',
      testFile: testFilePath,
      lastRunError: '',
      promptFile: '', // Add this line
      maxRuns: argv.flags.maxRuns,
      threadId: argv.flags.thread || '',
      testFilepath: argv.flags.testFilepath || '',
      testFileOutputPath: argv.flags.testFileOutputPath || '',
      coverageReportPath: argv.flags.coverageReportPath || '',
      testCommandDirectory: argv.flags.testCommandDirectory || '',
      includedFiles: argv.flags.includedFiles
        ? argv.flags.includedFiles.map(String)
        : [],
      coverageType: argv.flags.coverageType || '',
      reportFilepath: argv.flags.reportFilepath || '',
      desiredCoverage: argv.flags.desiredCoverage || 90,
    };

    // //validate testFilePath
    // if (!testFilePath) {
    //   console.error(red('✖') + ' Test file path not found');
    //   process.exit(1);
    // }
    // // If the test file output path is set, copy the test file there
    // if (argv.flags.testFileOutputPath) {
    //   copyFileSync(testFilePath, argv.flags.testFileOutputPath);
    // }
    // // Otherwise, set the test file output path to the current test file
    // else {
    //   argv.flags.testFileOutputPath = testFilePath;
    // }
    try {
      if (!argv._.filePath || !argv.flags.testFilepath) {
        const isValidproject = await isValidProject();

        if (!isValidproject) {
          await invalidProjectWarningMessage();
        } else {
          await interactiveMode(runOptions);
        }
        return;
      }

      //validate filepath and testfilepath
      // if (!argv._.filePath || !argv.flags.testFilepath) {
      //   console.error(red('✖') + ' File path or test file path not found');
      //   process.exit(1);
      // }

      await runAll(runOptions);
    } catch (error: any) {
      console.error(`\n${red('✖')} ${error.message || error}`);
      handleCliError(error);
      process.exit(1);
    }
  }
);

process.on('SIGINT', () => {
  console.log('\n');
  outro(red('Stopping.'));
  console.log('\n');
  process.exit();
});
