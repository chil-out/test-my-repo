from importlib import resources
from typing import Any, Dict, List

from grep_ast import filename_to_lang
from tree_sitter_languages import get_language, get_parser

from mutahunter.core.logger import logger


class Analyzer:
    """
    代码分析器类，用于分析源代码文件的结构和内容。
    
    主要功能包括:
    - 识别文件的编程语言
    - 分析代码覆盖率
    - 提取函数和方法块
    - 语法检查
    - 查找特定函数和导入语句
    """

    def __init__(self) -> None:
        pass

    def get_language_by_filename(self, filename: str) -> str:
        """
        根据文件名获取编程语言标识符。

        Args:
            filename (str): 文件名

        Returns:
            str: 编程语言标识符
        """
        return filename_to_lang(filename)

    def get_covered_function_blocks(
        self, executed_lines: List[int], source_file_path: str
    ) -> List[Any]:
        """
        获取已覆盖的函数块。
        根据已执行的行号和源文件路径，识别哪些函数块被测试覆盖到。

        Args:
            executed_lines (List[int]): 已执行的行号列表
            source_file_path (str): 源文件路径

        Returns:
            List[Any]: 已覆盖的函数块列表
        """
        function_blocks = self.get_function_blocks(source_file_path=source_file_path)
        return self._get_covered_blocks(function_blocks, executed_lines)

    def get_covered_method_blocks(
        self, executed_lines: List[int], source_file_path: str
    ) -> List[Any]:
        """
        获取已覆盖的方法块。
        根据已执行的行号和源文件路径，识别哪些方法块被测试覆盖到。

        Args:
            executed_lines (List[int]): 已执行的行号列表
            source_file_path (str): 源文件路径

        Returns:
            List[Any]: 已覆盖的方法块列表
        """
        method_blocks = self.get_method_blocks(source_file_path=source_file_path)
        return self._get_covered_blocks(method_blocks, executed_lines)

    def _get_covered_blocks(
        self, blocks: List[Any], executed_lines: List[int]
    ) -> List[Any]:
        """
        获取已覆盖的代码块。
        根据代码块列表和已执行行号，确定哪些代码块被覆盖。

        Args:
            blocks (List[Any]): 代码块列表(函数或方法)
            executed_lines (List[int]): 已执行的行号列表

        Returns:
            List[Any]: 已覆盖的代码块列表和对应的已执行行号
        """
        covered_blocks = []
        covered_block_executed_lines = []

        for block in blocks:
            # 0 baseed index
            start_point = block.start_point
            end_point = block.end_point

            start_line = start_point[0] + 1
            end_line = end_point[0] + 1

            if any(line in executed_lines for line in range(start_line, end_line + 1)):
                block_executed_lines = [
                    line - start_line + 1 for line in range(start_line, end_line + 1)
                ]
                covered_blocks.append(block)
                covered_block_executed_lines.append(block_executed_lines)

        return covered_blocks, covered_block_executed_lines

    def get_method_blocks(self, source_file_path: str) -> List[Any]:
        """
        从给定文件中获取方法块。
        解析源文件并提取所有的方法定义块。

        Args:
            source_file_path (str): 源文件路径

        Returns:
            List[Any]: 方法块节点列表
        """
        source_code = self._read_source_file(source_file_path)
        return self.find_method_blocks_nodes(source_file_path, source_code)

    def get_function_blocks(self, source_file_path: str) -> List[Any]:
        """
        从给定文件中获取函数块。
        解析源文件并提取所有的函数定义块。

        Args:
            source_file_path (str): 源文件路径

        Returns:
            List[Any]: 函数块节点列表
        """
        source_code = self._read_source_file(source_file_path)
        return self.find_function_blocks_nodes(source_file_path, source_code)

    def _read_source_file(self, file_path: str) -> bytes:
        """
        读取源代码文件内容。

        Args:
            file_path (str): 源文件路径

        Returns:
            bytes: 源代码内容
        """
        with open(file_path, "rb") as f:
            return f.read()

    def check_syntax(self, source_file_path: str, source_code: str) -> bool:
        """
        检查源代码的语法是否正确。
        使用tree-sitter解析器验证代码语法。

        Args:
            source_code (str): 要检查的源代码

        Returns:
            bool: 语法正确返回True，否则返回False
        """
        lang = filename_to_lang(source_file_path)
        parser = get_parser(lang)
        tree = parser.parse(bytes(source_code, "utf8"))
        return not tree.root_node.has_error

    def find_method_blocks_nodes(
        self, source_file_path: str, source_code: bytes
    ) -> List[Any]:
        """
        在源代码中查找方法块节点。
        查找包括if语句、循环和return语句等。

        Args:
            source_code (bytes): 要分析的源代码

        Returns:
            List[Any]: 方法块节点列表
        """
        return self._find_blocks_nodes(
            source_file_path, source_code, ["if_statement", "loop", "return"]
        )

    def find_function_blocks_nodes(
        self, source_file_path: str, source_code: bytes
    ) -> List[Any]:
        """
        在源代码中查找函数块节点。
        查找函数和方法的定义。

        Args:
            source_code (bytes): 要分析的源代码

        Returns:
            List[Any]: 函数块节点列表
        """
        return self._find_blocks_nodes(
            source_file_path, source_code, ["definition.function", "definition.method"]
        )

    def _find_blocks_nodes(
        self, source_file_path: str, source_code: bytes, tags: List[str]
    ) -> List[Any]:
        """
        在源代码中查找指定类型的代码块节点。
        使用tree-sitter解析器和查询来定位特定类型的代码块。

        Args:
            source_code (bytes): 要分析的源代码
            tags (List[str]): 用于标识代码块的标签列表

        Returns:
            List[Any]: 代码块节点列表
        """
        lang = filename_to_lang(source_file_path)
        if lang is None:
            raise ValueError(f"Language not supported for file: {source_file_path}")
        parser = get_parser(lang)
        language = get_language(lang)

        tree = parser.parse(source_code)

        # def traverse_tree(node, depth=0):
        #     print("  " * depth + f"{node.type}: {node.text.decode('utf8')}")
        #     for child in node.children:
        #         traverse_tree(child, depth + 1)

        # traverse_tree(tree.root_node)

        query_scm = self._load_query_scm(lang)
        if not query_scm:
            return []

        query = language.query(query_scm)
        captures = query.captures(tree.root_node)
        # for node, tag in captures:
        #     print(node, tag)
        # print code
        # print(source_code[node.start_byte : node.end_byte].decode("utf8"))

        if not captures:
            logger.error("Tree-sitter query failed to find any captures.")
            return []
        return [node for node, tag in captures if tag in tags]

    def _load_query_scm(self, lang: str) -> str:
        """
        加载查询SCM文件内容。
        根据编程语言加载对应的tree-sitter查询文件。

        Args:
            lang (str): 编程语言标识符

        Returns:
            str: 查询SCM文件内容
        """
        try:
            scm_fname = resources.files(__package__).joinpath(
                "queries", f"tree-sitter-{lang}-tags.scm"
            )
        except KeyError:
            return ""
        if not scm_fname.exists():
            return ""
        return scm_fname.read_text()

    def find_function_block_by_name(
        self, source_file_path: str, method_name: str
    ) -> List[Any]:
        """
        根据函数名查找函数块，并返回函数的起始和结束行。

        Args:
            source_file_path (str): 源文件路径
            method_name (str): 要查找的方法名

        Returns:
            Dict[str, int]: 包含'start_line'和'end_line'的字典，表示函数的起始和结束行号

        Raises:
            ValueError: 当找不到指定函数时抛出
        """
        source_code = self._read_source_file(source_file_path)
        lang = filename_to_lang(source_file_path)
        if lang is None:
            raise ValueError(f"Language not supported for file: {source_file_path}")

        parser = get_parser(lang)
        language = get_language(lang)
        tree = parser.parse(source_code)

        query_scm = self._load_query_scm(lang)
        if not query_scm:
            raise ValueError(
                "Failed to load query SCM file for the specified language."
            )

        query = language.query(query_scm)
        captures = query.captures(tree.root_node)

        result = []

        for node, tag in captures:
            if tag == "definition.function" or tag == "definition.method":
                if self._is_function_name(node, method_name, source_code):
                    return node
        raise ValueError(f"Function {method_name} not found in file {source_file_path}")

    def _is_function_name(self, node, method_name: str, source_code: bytes) -> bool:
        """
        检查给定节点是否对应指定的方法名。

        Args:
            node (Node): 要检查的AST节点
            method_name (str): 要查找的方法名
            source_code (bytes): 源代码

        Returns:
            bool: 如果节点对应指定方法名则返回True，否则返回False
        """
        node_text = source_code[node.start_byte : node.end_byte].decode("utf8")
        return method_name in node_text

    def get_import_nodes(self, source_file_path: str) -> List[Any]:
        """
        从给定文件中获取导入语句节点。

        Args:
            source_file_path (str): 源文件路径

        Returns:
            List[Any]: 导入语句节点列表
        """
        source_code = self._read_source_file(source_file_path)
        return self._find_blocks_nodes(source_file_path, source_code, ["import"])

    def get_test_nodes(self, source_file_path: str) -> List[Any]:
        """
        从给定文件中获取测试方法节点。

        Args:
            source_file_path (str): 源文件路径

        Returns:
            List[Any]: 测试方法节点列表
        """
        source_code = self._read_source_file(source_file_path)
        return self._find_blocks_nodes(source_file_path, source_code, ["test.method"])
