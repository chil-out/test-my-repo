import time

import yaml
from litellm import completion, litellm

from mutahunter.core.prompt_factory import YAMLFixerPromptFactory


class LLMRouter:
    """
    LLM路由器类，负责处理与大语言模型的交互。
    主要功能包括:
    - 初始化和配置LLM模型
    - 生成响应
    - 处理流式和非流式响应
    - 跟踪API调用成本
    - 处理YAML格式的响应
    """

    def __init__(self, model: str, api_base: str = "") -> None:
        """
        初始化LLM路由器，设置模型和API基础URL。

        Args:
            model (str): 要使用的LLM模型名称
            api_base (str): API基础URL，可选
        """
        self.model = model
        self.api_base = api_base
        self.total_cost = 0  # 跟踪总API调用成本
        litellm.success_callback = [self.track_cost_callback]
        self.yaml_prompt = YAMLFixerPromptFactory().get_prompt()

    def track_cost_callback(
        self,
        kwargs,  # completion的参数
        completion_response,  # completion的响应
        start_time,
        end_time,  # 开始/结束时间
    ):
        """
        跟踪API调用成本的回调函数。
        在每次成功调用API后更新总成本。
        """
        try:
            response_cost = kwargs.get("response_cost", 0)
            self.total_cost += response_cost
        except:
            pass

    def generate_response(
        self, prompt: dict, max_tokens: int = 4096, streaming: bool = False
    ) -> tuple:
        """
        使用提供的提示调用LLM模型并返回生成的响应。

        Args:
            prompt (dict): 包含'system'和'user'键的字典
            max_tokens (int): 响应的最大令牌数
            streaming (bool): 是否启用流式响应

        Returns:
            tuple: 生成的响应、使用的提示令牌数和完成令牌数
        """
        self._validate_prompt(prompt)
        messages = self._build_messages(prompt)
        completion_params = self._build_completion_params(
            messages, max_tokens, streaming
        )

        try:
            if streaming:
                response_chunks = self._stream_response(completion_params)
                return self._process_response(response_chunks, messages)
            else:
                return self._non_stream_response(completion_params)
        except Exception as e:
            print(f"Error during response generation: {e}")
            return "", 0, 0

    def _validate_prompt(self, prompt: dict) -> None:
        """
        验证提示字典是否包含所需的键。

        Args:
            prompt (dict): 要验证的提示字典
        
        Raises:
            Exception: 如果缺少必需的键
        """
        if "system" not in prompt or "user" not in prompt:
            raise Exception(
                "The prompt dictionary must contain 'system' and 'user' keys."
            )

    def _build_messages(self, prompt: dict) -> list:
        """
        从提示字典构建消息列表。

        Args:
            prompt (dict): 包含system和user提示的字典

        Returns:
            list: 格式化的消息列表
        """
        return [
            {"role": "system", "content": prompt["system"]},
            {"role": "user", "content": prompt["user"]},
        ]

    def _build_completion_params(
        self, messages: list, max_tokens: int, streaming: bool
    ) -> dict:
        """
        构建LLM completion调用的参数。

        Args:
            messages (list): 消息列表
            max_tokens (int): 最大令牌数
            streaming (bool): 是否启用流式响应

        Returns:
            dict: completion参数字典
        """
        completion_params = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "stream": streaming,
            "temperature": 0.0,
        }
        if (
            "ollama" in self.model
            or "huggingface" in self.model
            or self.model.startswith("openai/")
        ):
            completion_params["api_base"] = self.api_base
        return completion_params

    def _stream_response(self, completion_params: dict) -> list:
        """
        从LLM模型获取流式响应。

        Args:
            completion_params (dict): completion参数

        Returns:
            list: 响应块列表
        """
        response_chunks = []
        print("\nStreaming results from LLM model...")
        response = completion(**completion_params)
        for chunk in response:
            print(chunk.choices[0].delta.content or "", end="", flush=True)
            response_chunks.append(chunk)
            time.sleep(
                0.01
            )  # 可选：添加延迟以模拟更自然的响应节奏
        print("\n")
        return response_chunks

    def _non_stream_response(self, completion_params: dict) -> tuple:
        """
        从LLM模型获取非流式响应。

        Args:
            completion_params (dict): completion参数

        Returns:
            tuple: 内容、提示令牌数和完成令牌数
        """
        response = completion(**completion_params)
        content = response["choices"][0]["message"]["content"]
        prompt_tokens = int(response["usage"]["prompt_tokens"])
        completion_tokens = int(response["usage"]["completion_tokens"])
        return content, prompt_tokens, completion_tokens

    def _process_response(self, response_chunks: list, messages: list) -> tuple:
        """
        处理流式响应块，生成最终响应。

        Args:
            response_chunks (list): 响应块列表
            messages (list): 原始消息列表

        Returns:
            tuple: 内容、提示令牌数和完成令牌数
        """
        model_response = litellm.stream_chunk_builder(
            response_chunks, messages=messages
        )
        content = model_response["choices"][0]["message"]["content"]
        prompt_tokens = int(model_response["usage"]["prompt_tokens"])
        completion_tokens = int(model_response["usage"]["completion_tokens"])
        return content, prompt_tokens, completion_tokens

    def extract_yaml_from_response(self, response: str) -> dict:
        """
        从响应中提取并解析YAML内容。

        Args:
            response (str): 包含YAML的响应字符串

        Returns:
            dict: 解析后的YAML数据，如果解析失败则返回空列表
        """
        response = response.strip().removeprefix("```yaml").removesuffix("```")
        max_retries = 3

        for attempt in range(max_retries):
            try:
                return yaml.safe_load(response)
            except Exception as e:
                if attempt < max_retries - 1:
                    print("attempting to fix yaml")
                    response = self._attempt_yaml_fix(str(e), response)
                else:
                    return []

    def _attempt_yaml_fix(self, error, content):
        """
        尝试修复无效的YAML内容。

        Args:
            error (str): YAML解析错误信息
            content (str): 需要修复的YAML内容

        Returns:
            str: 修复后的YAML内容
        """
        user_prompt = self.yaml_prompt.yaml_fixer_user_prompt.render(
            {
                "content": content,
                "error": error,
            }
        )
        fix_response, _, _ = self.generate_response(
            prompt={"system": "", "user": user_prompt}, streaming=False
        )
        return fix_response
