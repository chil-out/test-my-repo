import os
import xml.etree.ElementTree as ET
from typing import Dict, List


class CoverageProcessor:
    def __init__(self, coverage_type: str, code_coverage_report_path: str) -> None:
        """
        初始化覆盖率处理器

        Args:
            coverage_type: 覆盖率报告类型 ('cobertura', 'jacoco', 或 'lcov')
            code_coverage_report_path: 覆盖率报告文件路径
        """
        self.coverage_type = coverage_type
        self.code_coverage_report_path = code_coverage_report_path

        # 总体行覆盖率
        self.line_coverage_rate = 0.00
        # 记录每个源文件中已执行的行号
        self.file_lines_executed = {}  # src_file -> [line_numbers]
        # 记录每个源文件中未执行的行号
        self.file_lines_not_executed = {}  # src_file -> [line_numbers]

    def parse_coverage_report(self) -> Dict[str, List[int]]:
        """
        根据覆盖率类型解析相应的覆盖率报告

        根据self.coverage_type选择对应的解析器来处理覆盖率报告,
        并计算总体行覆盖率

        Returns:
            Dict[str, List[int]]: 文件名到已覆盖行号列表的映射
        """
        coverage_type_parsers = {
            "lcov": self.parse_coverage_report_lcov,
            "cobertura": self.parse_coverage_report_cobertura,
            "jacoco": self.parse_coverage_report_jacoco,
        }

        if self.coverage_type in coverage_type_parsers:
            coverage_type_parsers[self.coverage_type]()
            self.line_coverage_rate = self.calculate_line_coverage_rate()
        else:
            raise ValueError(
                "Invalid coverage tool. Please specify either 'cobertura', 'jacoco', or 'lcov'."
            )

    def parse_coverage_report_lcov(self):
        """
        解析LCOV格式的覆盖率报告
        
        LCOV报告使用.info文件格式,包含每个源文件的行覆盖信息
        """
        self._check_file_exists(self.code_coverage_report_path)
        self._check_file_extension([".info"], self.code_coverage_report_path)

        self.file_lines_executed.clear()
        self.file_lines_not_executed.clear()

        current_file = None
        with open(self.code_coverage_report_path, "r") as file:
            lines = file.readlines()
            for line in lines:
                if line.startswith("SF:"):
                    current_file = line.strip().split(":", 1)[1]
                    if current_file not in self.file_lines_executed:
                        self.file_lines_executed[current_file] = []
                    if current_file not in self.file_lines_not_executed:
                        self.file_lines_not_executed[current_file] = []
                elif line.startswith("DA:") and current_file:
                    parts = line.strip().split(":")[1].split(",")
                    hits = int(parts[1])
                    if hits > 0:
                        line_number = int(parts[0])
                        self.file_lines_executed[current_file].append(line_number)
                    else:
                        line_number = int(parts[0])
                        self.file_lines_not_executed[current_file].append(line_number)
                elif line.startswith("end_of_record"):
                    current_file = None

    def parse_coverage_report_cobertura(self):
        """
        解析Cobertura格式的覆盖率报告
        
        Cobertura使用XML格式存储覆盖率信息,包含类和方法级别的覆盖数据
        """
        self._check_file_exists(self.code_coverage_report_path)
        self._check_file_extension([".xml"], self.code_coverage_report_path)

        self.file_lines_executed.clear()
        self.file_lines_not_executed.clear()

        tree = ET.parse(self.code_coverage_report_path)
        root = tree.getroot()

        for cls in root.findall(".//class"):
            name_attr = cls.get("filename")
            if name_attr not in self.file_lines_executed:
                self.file_lines_executed[name_attr] = []
            if name_attr not in self.file_lines_not_executed:
                self.file_lines_not_executed[name_attr] = []
            for line in cls.findall(".//line"):
                line_number = int(line.get("number"))
                hits = int(line.get("hits"))
                if hits > 0:
                    self.file_lines_executed[name_attr].append(line_number)
                else:
                    self.file_lines_not_executed[name_attr].append(line_number)

    def parse_coverage_report_jacoco(self):
        """
        解析JaCoCo格式的覆盖率报告
        
        JaCoCo使用XML格式,按包和源文件组织覆盖率数据
        """
        self._check_file_exists(self.code_coverage_report_path)
        self._check_file_extension([".xml"], self.code_coverage_report_path)
        self.file_lines_executed.clear()
        self.file_lines_not_executed.clear()
        tree = ET.parse(self.code_coverage_report_path)
        root = tree.getroot()

        for package in root.findall(".//package"):
            # package_name = package.get("name").replace("/", ".")
            for sourcefile in package.findall(".//sourcefile"):
                filename = sourcefile.get("name")
                full_filename = self.find_source_file(filename)
                full_filename = full_filename.replace(os.getcwd() + "/", "")
                if full_filename not in self.file_lines_executed:
                    self.file_lines_executed[full_filename] = []
                if full_filename not in self.file_lines_not_executed:
                    self.file_lines_not_executed[full_filename] = []

                for line in sourcefile.findall(".//line"):
                    line_number = int(line.get("nr"))  # nr is the line number
                    covered = int(line.get("ci"))  # ci is the covered lines
                    # missing = int(line.get("mi"))  # mi is the missed lines
                    if covered > 0:
                        self.file_lines_executed[full_filename].append(line_number)
                    else:
                        self.file_lines_not_executed[full_filename].append(line_number)

    def find_source_file(self, filename: str):
        """
        在项目目录中查找源文件的完整路径
        
        Args:
            filename: 要查找的文件名
            
        Returns:
            str: 找到的文件完整路径
        """
        for root, dirs, files in os.walk(os.getcwd()):
            for file in files:
                if "src" in root and filename in file:
                    return os.path.join(root, file)

    def calculate_line_coverage_rate_for_file(self, src_file: str):
        """
        计算单个文件的行覆盖率
        
        Args:
            src_file: 源文件路径
            
        Returns:
            float: 该文件的行覆盖率(0.00-1.00)
        """
        lines_executed = self.file_lines_executed.get(src_file, [])
        lines_not_executed = self.file_lines_not_executed.get(src_file, [])
        if len(lines_executed) + len(lines_not_executed) == 0:
            line_cov = 0.00
        else:
            line_cov = len(lines_executed) / (
                len(lines_executed) + len(lines_not_executed)
            )
        return line_cov

    def calculate_line_coverage_rate(self) -> float:
        """
        计算所有文件的总体行覆盖率
        
        Returns:
            float: 总体行覆盖率(0.00-1.00)
        """
        total_executed_lines = sum(
            len(lines) for lines in self.file_lines_executed.values()
        )
        total_missed_lines = sum(
            len(lines) for lines in self.file_lines_not_executed.values()
        )
        if total_executed_lines + total_missed_lines == 0:
            return 0.00
        return round(
            total_executed_lines / (total_executed_lines + total_missed_lines), 2
        )

    def _check_file_exists(self, file_path: str):
        """检查文件是否存在"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File '{file_path}' not found.")

    def _check_file_extension(self, exts: List[str], file_path: str):
        """检查文件扩展名是否符合要求"""
        if not any(file_path.endswith(ext) for ext in exts):
            raise ValueError(f"File '{file_path}' is not in {exts} format.")
