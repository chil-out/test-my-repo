import os
import shutil

from mutahunter.core.logger import logger


class FileUtils:
    """文件操作工具类，提供文件读取、备份和还原等基础功能"""

    @staticmethod
    def read_file(path: str) -> str:
        """
        读取文件内容
        Args:
            path: 文件路径
        Returns:
            文件内容字符串
        """
        try:
            with open(path, "r") as file:
                return file.read()
        except FileNotFoundError:
            logger.info(f"File not found: {path}")
        except Exception as e:
            logger.info(f"Error reading file {path}: {e}")
            raise

    @staticmethod
    def number_lines(code: str) -> str:
        """
        为代码添加行号
        Args:
            code: 原始代码字符串
        Returns:
            添加行号后的代码字符串
        """
        return "\n".join(f"{i + 1} {line}" for i, line in enumerate(code.splitlines()))

    @staticmethod
    def backup_code(file_path: str) -> None:
        """
        备份源代码文件
        Args:
            file_path: 需要备份的文件路径
        """
        backup_path = f"{file_path}.bak"
        try:
            shutil.copyfile(file_path, backup_path)
        except Exception as e:
            logger.info(f"Failed to create backup file for {file_path}: {e}")
            raise

    @staticmethod
    def revert(file_path: str) -> None:
        """
        从备份文件还原源文件
        Args:
            file_path: 需要还原的文件路径
        """
        backup_path = f"{file_path}.bak"
        try:
            if os.path.exists(backup_path):
                shutil.copyfile(backup_path, file_path)
            else:
                logger.info(f"No backup file found for {file_path}")
                raise FileNotFoundError(f"No backup file found for {file_path}")
        except Exception as e:
            logger.info(f"Failed to revert file {file_path}: {e}")
            raise
