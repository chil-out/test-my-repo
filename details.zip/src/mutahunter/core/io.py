import os
from typing import Any, Dict, List, Optional
from uuid import uuid4

from grep_ast import filename_to_lang
from tree_sitter_languages import get_language, get_parser

# 测试文件的常见命名模式,用于识别测试文件
TEST_FILE_PATTERNS = [
    "test_",
    "_test", 
    ".test",
    ".spec",
    ".tests", 
    ".Test",
    "tests/",
    "test/",
]


class FileOperationHandler:
    """文件操作处理类,提供文件读写和变异体生成相关的功能"""
    
    @staticmethod
    def read_file(file_path: str) -> str:
        """读取文件内容"""
        with open(file_path, "r") as f:
            return f.read()

    @staticmethod 
    def write_file(file_path: str, content: str) -> None:
        """写入文件内容"""
        with open(file_path, "w") as f:
            f.write(content)

    @staticmethod
    def get_mutant_path(source_file_path: str, mutant_id: str) -> str:
        """
        生成变异体文件的保存路径
        Args:
            source_file_path: 源文件路径
            mutant_id: 变异体ID
        Returns:
            变异体文件的完整路径
        """
        mutant_file_name = f"{mutant_id}_{os.path.basename(source_file_path)}"
        return os.path.join(os.getcwd(), f"logs/_latest/mutants/{mutant_file_name}")

    @staticmethod
    def prepare_mutant_file(
        mutant_data: Dict[str, Any], source_file_path: str
    ) -> Optional[str]:
        """
        准备变异体文件
        Args:
            mutant_data: 变异体数据,包含变异信息
            source_file_path: 源文件路径
        Returns:
            生成的变异体文件路径,如果生成失败则返回None
        """
        mutant_id = str(uuid4())[:8]  # 生成8位的唯一ID
        mutant_path = FileOperationHandler.get_mutant_path(source_file_path, mutant_id)
        source_code = FileOperationHandler.read_file(source_file_path)
        applied_mutant = FileOperationHandler.apply_mutation(source_code, mutant_data)
        if not FileOperationHandler.check_syntax(source_file_path, applied_mutant):
            raise SyntaxError("Mutant syntax is incorrect.")
        FileOperationHandler.write_file(mutant_path, applied_mutant)
        return mutant_path

    @staticmethod
    def should_skip_file(
        filename: str, exclude_files: List[str], only_mutate_file_paths: List[str]
    ) -> bool:
        """
        判断是否应该跳过某个文件的变异
        Args:
            filename: 文件名
            exclude_files: 需要排除的文件列表
            only_mutate_file_paths: 仅变异的文件路径列表
        Returns:
            是否应该跳过该文件
        """
        if only_mutate_file_paths:
            for file_path in only_mutate_file_paths:
                if not os.path.exists(file_path):
                    raise FileNotFoundError(f"File {file_path} does not exist.")
            return all(file_path != filename for file_path in only_mutate_file_paths)
        if filename in exclude_files:
            return True

    @staticmethod
    def check_syntax(source_file_path: str, source_code: str) -> bool:
        """
        检查源代码的语法是否正确
        Args:
            source_file_path: 源文件路径,用于确定编程语言
            source_code: 需要检查的源代码
        Returns:
            语法是否正确
        """
        lang = filename_to_lang(source_file_path)
        parser = get_parser(lang)
        tree = parser.parse(bytes(source_code, "utf8"))
        return not tree.root_node.has_error

    @staticmethod
    def apply_mutation(source_code: str, mutant_data: Dict[str, Any]) -> str:
        """
        将变异应用到源代码上
        Args:
            source_code: 原始源代码
            mutant_data: 变异数据,包含变异行号和变异后的代码
        Returns:
            应用变异后的源代码
        """
        src_code_lines = source_code.splitlines(keepends=True)
        mutated_line = mutant_data["mutated_code"].strip()
        line_number = mutant_data["line_number"]

        # 保持原有的缩进
        indentation = len(src_code_lines[line_number - 1]) - len(
            src_code_lines[line_number - 1].lstrip()
        )
        src_code_lines[line_number - 1] = " " * indentation + mutated_line + "\n"

        return "".join(src_code_lines)
