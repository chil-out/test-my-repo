import os
from typing import Any, Dict, List, Optional

import yaml
from grep_ast import filename_to_lang
from jinja2 import Template

from mutahunter.core.logger import logger
from mutahunter.core.prompt_factory import MutationTestingPrompt
from mutahunter.core.repomap import RepoMap
from mutahunter.core.router import LLMRouter

SYSTEM_YAML_FIX = """
Based on the error message, the YAML content provided is not in the correct format. Please ensure the YAML content is in the correct format and try again.
"""

USER_YAML_FIX = """
YAML content:
```yaml
{{yaml_content}}
```

Error:
{{error}}

Output must be wrapped in triple backticks and in YAML format:
```yaml
...fix the yaml content here...
```
"""

class LLMMutationEngine:
    """LLM变异测试引擎类,用于生成代码变异体"""
    
    MAX_RETRIES = 2  # 最大重试次数

    def __init__(
        self,
        model: str,  # 使用的语言模型名称
        router: LLMRouter,  # LLM路由器实例
        prompt: MutationTestingPrompt,  # 变异测试提示模板
    ) -> None:
        self.model = model
        self.router = router
        self.repo_map = RepoMap(model=self.model)  # 代码仓库映射实例
        self.prompt = prompt
        self.num = 0  # 生成的变异体计数器

    def get_source_code(self, source_file_path: str) -> str:
        """读取源代码文件内容"""
        with open(source_file_path, "r") as f:
            return f.read()

    def _add_line_numbers(self, src_code: str) -> str:
        """为源代码添加行号"""
        return "\n".join(
            [f"{i + 1} {line}" for i, line in enumerate(src_code.splitlines())]
        )

    def generate_mutant(
        self,
        repo_map_result: Dict[str, Any],  # 代码仓库映射结果
        source_file_path: str,  # 源文件路径
        executed_lines: List[int],  # 已执行的代码行号
    ) -> str:
        """
        生成代码变异体
        
        Args:
            repo_map_result: 代码仓库的AST映射结果
            source_file_path: 待变异的源文件路径
            executed_lines: 测试覆盖的代码行号列表
            
        Returns:
            str: LLM生成的变异体描述(YAML格式)
        """
        language = filename_to_lang(source_file_path)  # 获取源文件的编程语言
        src_code = self.get_source_code(source_file_path)  # 读取源代码
        src_code_with_line_num = self._add_line_numbers(src_code)  # 添加行号

        # 渲染系统提示模板
        system_template = self.prompt.mutator_system_prompt.render(
            {
                "language": language,
            }
        )
        # 渲染用户提示模板
        user_template = self.prompt.mutator_user_prompt.render(
            {
                "language": language,
                "ast": repo_map_result,
                "covered_lines": executed_lines,
                "src_code_with_line_num": src_code_with_line_num,
                "maximum_num_of_mutants_per_function_block": 2,
            }
        )
        prompt = {"system": system_template, "user": user_template}
        model_response, _, _ = self.router.generate_response(
            prompt=prompt, streaming=True
        )
        return model_response

    def generate(
        self, source_file_path: str, executed_lines: List[int], cov_files: List[str]
    ) -> Dict[str, Any]:
        """
        生成变异体的主入口方法
        
        Args:
            source_file_path: 源文件路径
            executed_lines: 已执行的代码行号
            cov_files: 测试覆盖的文件列表
            
        Returns:
            Dict[str, Any]: 包含变异体信息的字典
        """
        repo_map_result = self._get_repo_map(cov_files=cov_files)  # 获取代码仓库映射
        if not repo_map_result:
            logger.info("Current language is not supported for retrieving AST.")

        response = self.generate_mutant(
            repo_map_result, source_file_path, executed_lines
        )
        extracted_response = self.extract_response(response)  # 提取并解析YAML响应
        self._save_yaml(extracted_response)  # 保存YAML输出
        return extracted_response

    def extract_response(self, response: str) -> Dict[str, Any]:
        """
        从LLM响应中提取并解析YAML内容
        
        包含重试机制,最多重试MAX_RETRIES次
        """
        for attempt in range(self.MAX_RETRIES):
            try:
                cleaned_response = self._clean_response(response)
                data = yaml.safe_load(cleaned_response)
                return data
            except Exception as e:
                logger.error(f"Error extracting YAML content: {e}")
                if attempt < self.MAX_RETRIES - 1:
                    logger.info(f"Retrying to extract YAML with retry {attempt + 1}...")
                    response = self.fix_format(e, response)
                else:
                    logger.error(
                        f"Error extracting YAML content after {self.MAX_RETRIES} attempts: {e}"
                    )
        return {"mutants": []}

    def fix_format(self, error: Exception, content: str) -> str:
        """修复YAML格式错误"""
        system_template = Template(SYSTEM_YAML_FIX).render()
        user_template = Template(USER_YAML_FIX).render(
            yaml_content=content, error=error
        )
        prompt = {"system": system_template, "user": user_template}
        model_response, _, _ = self.router.generate_response(
            prompt=prompt, streaming=True
        )
        return model_response

    def _get_repo_map(self, cov_files: List[str]) -> Optional[Dict[str, Any]]:
        """获取代码仓库的AST映射"""
        return self.repo_map.get_repo_map(chat_files=[], other_files=cov_files)

    def _add_line_numbers(self, src_code: str) -> str:
        """为源代码添加行号"""
        return "\n".join(
            [f"{i + 1} {line}" for i, line in enumerate(src_code.splitlines())]
        )

    def _clean_response(self, response: str) -> str:
        """清理LLM响应中的YAML内容"""
        return response.strip().removeprefix("```yaml").rstrip("`")

    def _save_yaml(self, data: Dict[str, Any]) -> None:
        """保存YAML输出到文件"""
        output = f"output_{self.num}.yaml"
        with open(os.path.join("logs/_latest/llm", output), "w") as f:
            yaml.dump(data, f, default_flow_style=False, indent=2)
        self.num += 1
        logger.info(f"YAML output saved to {output}")
