import logging
import os
import warnings

# 忽略来自tree_sitter的特定FutureWarning警告
warnings.filterwarnings("ignore", category=FutureWarning, module="tree_sitter")


def setup_logger(name: str) -> logging.Logger:
    """
    配置并创建一个日志记录器
    
    创建必要的日志目录结构,设置日志格式和处理器,
    支持同时输出到文件和控制台
    
    Args:
        name: 日志记录器名称
        
    Returns:
        配置好的日志记录器实例
    """
    # 创建日志所需的目录结构
    os.makedirs("logs/_latest", exist_ok=True)  # 主日志目录
    os.makedirs("logs/_latest/llm", exist_ok=True)  # LLM相关日志目录
    os.makedirs("logs/_latest/mutants", exist_ok=True)  # 变异体相关日志目录
    os.makedirs("logs/_latest/unittest", exist_ok=True)  # 单元测试相关日志目录

    # 设置日志格式: 时间 日志级别: 消息内容
    log_format = "%(asctime)s %(levelname)s: %(message)s"

    # 创建文件处理器,将日志写入文件
    file_handler = logging.FileHandler(
        filename=os.path.join("logs", "_latest", "debug.log"),
        mode="w",  # 写入模式,每次覆盖之前的日志
        encoding="utf-8",
    )
    # 创建流处理器,将日志输出到控制台
    stream_handler = logging.StreamHandler()

    # 将自定义格式应用到处理器
    formatter = logging.Formatter(log_format)
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)

    # 创建日志记录器并添加处理器
    logger = logging.getLogger(name)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    logger.setLevel(logging.INFO)  # 设置日志级别为INFO

    return logger


# 创建全局日志记录器实例
logger = setup_logger("mutahunter")
