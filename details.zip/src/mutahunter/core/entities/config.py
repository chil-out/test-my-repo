from dataclasses import dataclass
from typing import List, Optional


@dataclass
class MutationTestControllerConfig:
    """突变测试控制器的配置类
    
    用于存储运行突变测试所需的各项配置参数
    
    Attributes:
        model: 使用的LLM模型名称
        api_base: LLM API的基础URL(用于自托管模型)
        test_command: 运行测试的命令(如 pytest)
        code_coverage_report_path: 代码覆盖率报告文件路径
        coverage_type: 覆盖率报告类型(cobertura/jacoco/lcov)
        exclude_files: 需要排除的文件列表
        only_mutate_file_paths: 仅对这些文件进行突变测试
        diff: 是否只测试git diff中的改动
    """
    model: str
    api_base: str
    test_command: str
    code_coverage_report_path: Optional[str]
    coverage_type: str
    exclude_files: List[str]
    only_mutate_file_paths: List[str]
    diff: bool


@dataclass
class UnittestGeneratorLineConfig:
    """基于行覆盖率的测试用例生成器配置类
    
    用于配置生成提升行覆盖率的测试用例所需的参数
    
    @dataclass 是Python的一个装饰器,它会自动为类生成:
    - __init__() 构造函数
    - __repr__() 字符串表示
    - __eq__() 相等比较
    等特殊方法,简化了数据类的定义
    
    Attributes:
        model: 使用的LLM模型名称
        api_base: LLM API的基础URL
        test_file_path: 测试文件路径
        source_file_path: 源代码文件路径
        test_command: 运行测试的命令
        code_coverage_report_path: 代码覆盖率报告路径
        coverage_type: 覆盖率报告类型
        target_line_coverage_rate: 目标行覆盖率
        max_attempts: 最大尝试次数
    """
    model: str
    api_base: str
    test_file_path: str
    source_file_path: str
    test_command: str
    code_coverage_report_path: Optional[str]
    coverage_type: str
    target_line_coverage_rate: float
    max_attempts: int


@dataclass
class UnittestGeneratorMutationConfig:
    """基于突变覆盖率的测试用例生成器配置类
    
    用于配置生成提升突变覆盖率的测试用例所需的参数
    
    Attributes:
        model: 使用的LLM模型名称
        api_base: LLM API的基础URL
        test_file_path: 测试文件路径
        source_file_path: 源代码文件路径
        test_command: 运行测试的命令
        code_coverage_report_path: 代码覆盖率报告路径
        coverage_type: 覆盖率报告类型
        target_mutation_coverage_rate: 目标突变覆盖率
        max_attempts: 最大尝试次数
    """
    model: str
    api_base: str
    test_file_path: str
    source_file_path: str
    test_command: str
    code_coverage_report_path: Optional[str]
    coverage_type: str
    target_mutation_coverage_rate: float
    max_attempts: int
