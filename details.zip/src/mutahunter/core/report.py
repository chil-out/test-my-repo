"""
变异测试报告生成模块。
用于生成详细的变异测试结果报告,包括HTML报告和文本摘要。
"""

import os
from importlib import resources
from typing import Any, Dict, List, Union

from jinja2 import Environment, FileSystemLoader, PackageLoader, select_autoescape

from mutahunter.core.db import MutationDatabase
from mutahunter.core.logger import logger

# ASCII艺术字体的MUTAHUNTER标志
MUTAHUNTER_ASCII = r"""
.  . . . .-. .-. . . . . . . .-. .-. .-. 
|\/| | |  |  |-| |-| | | |\|  |  |-  |(  
'  ` `-'  '  ` ' ' ` `-' ' `  '  `-' ' ' 
"""


class MutantReport:
    """变异测试报告生成类,用于生成HTML和文本格式的测试报告"""

    def __init__(self, db: MutationDatabase) -> None:
        """
        初始化报告生成器
        
        Args:
            db: 变异测试数据库实例,用于获取测试结果数据
        """
        self.log_file = "logs/_latest/coverage.txt"
        self.db = db
        # 创建HTML报告目录
        os.makedirs("logs/_latest/html", exist_ok=True)
        # 初始化Jinja2模板环境
        self.template_env = Environment(
            loader=FileSystemLoader(resources.files(__package__).joinpath("templates"))
        )
        # 验证必要的模板文件存在
        assert self.template_env.get_template("report_template.html")
        assert self.template_env.get_template("file_detail_template.html")

    def generate_report(self, total_cost: float, line_rate: float, run_id: int) -> None:
        """
        生成完整的变异测试报告
        
        Args:
            total_cost: 测试总成本
            line_rate: 代码行覆盖率
            run_id: 测试运行ID
        """
        print(MUTAHUNTER_ASCII)
        # 获取变异测试摘要数据
        data = self.db.get_mutant_summary(run_id)
        self._generate_summary_report(data, total_cost, line_rate)

        # 生成HTML报告
        file_data = self.db.get_file_data(run_id=run_id)
        # 生成主报告页面
        main_html = self._generate_main_report(data, file_data, total_cost, line_rate)
        self._write_html_report(main_html, "mutation_report.html")
        # 为每个源文件生成详细报告
        for file_info in file_data:
            file_html = self._generate_file_report(file_info["id"])
            self._write_html_report(file_html, f"{file_info['id']}.html")

    def _generate_main_report(
        self,
        summary_data: Dict[str, Any],
        file_data: List[Dict[str, Any]],
        total_cost: float,
        line_rate: float,
    ) -> str:
        """
        生成主HTML报告
        
        计算有效变异体数量和变异覆盖率,渲染主报告模板
        """
        # 计算有效变异体数量(排除编译错误和超时的变异体)
        valid_mutants = (
            summary_data["total_mutants"]
            - summary_data["compile_error_mutants"]
            - summary_data["timeout_mutants"]
        )
        # 计算变异覆盖率
        mutation_coverage = (
            f"{summary_data['killed_mutants'] / valid_mutants * 100:.2f}"
            if valid_mutants > 0
            else "0.00"
        )

        template = self.template_env.get_template("report_template.html")
        return template.render(
            line_coverage=f"{line_rate * 100:.2f}",
            mutation_coverage=mutation_coverage,
            total_mutants=summary_data["total_mutants"],
            killed_mutants=summary_data["killed_mutants"],
            survived_mutants=summary_data["survived_mutants"],
            timeout_mutants=summary_data["timeout_mutants"],
            compile_error_mutants=summary_data["compile_error_mutants"],
            total_cost=f"{total_cost:.7f}",
            file_data=file_data,
        )

    def _generate_file_report(self, file_id: str) -> str:
        """
        生成单个源文件的详细HTML报告
        
        显示源代码并标记变异点的状态(存活/被杀死)
        """
        file_name = self.db.get_source_file_by_id(file_id)
        source_code = self._get_source_code(file_name)
        mutations = self.db.get_file_mutations(file_name)

        source_lines = []
        for i, line in enumerate(source_code.splitlines(), start=1):
            # 获取当前行的所有变异
            line_mutations = [m for m in mutations if m["line_number"] == i]
            # 确定行状态:如果有存活的变异体则标记为survived,否则如果有变异则标记为killed
            gutter = (
                "survived"
                if any(m["status"] == "SURVIVED" for m in line_mutations)
                else "killed" if line_mutations else ""
            )
            source_lines.append(
                {"code": line, "gutter": gutter, "mutations": line_mutations}
            )

        template = self.template_env.get_template("file_detail_template.html")
        return template.render(file_name=file_name, source_lines=source_lines)

    def _get_source_code(self, file_name: str) -> str:
        """读取源代码文件内容"""
        with open(file_name, "r") as f:
            return f.read()

    def _write_html_report(self, html_content: str, filename: str) -> None:
        """
        将HTML报告写入文件
        
        Args:
            html_content: HTML内容
            filename: 输出文件名
        """
        with open(os.path.join("logs/_latest/html", filename), "w") as f:
            f.write(html_content)
        logger.info(f"HTML report generated: {filename}")

    def _generate_summary_report(
        self, data: Dict[str, Union[int, float]], total_cost: float, line_rate: float
    ) -> None:
        """
        生成文本格式的测试摘要报告
        
        Args:
            data: 测试结果数据
            total_cost: 测试总成本
            line_rate: 代码行覆盖率
        """
        summary_text = self._format_summary(data, total_cost, line_rate)
        self._log_and_write(summary_text)

    def _format_summary(
        self, data: Dict[str, Any], total_cost: float, line_rate: float
    ) -> str:
        """
        格式化测试摘要数据为可读的文本格式
        
        包含覆盖率、变异体数量统计和成本等信息
        """
        line_coverage = f"{line_rate * 100:.2f}%"
        mutation_coverage = f"{data['mutation_coverage']*100:.2f}%"
        details = [
            f"\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n",
            "📊 Overall Mutation Coverage 📊",
            f"📈 Line Coverage: {line_coverage} 📈",
            f"🎯 Mutation Coverage: {mutation_coverage} 🎯",
            f"🦠 Total Mutants: {data['total_mutants']} 🦠",
            f"🛡️ Survived Mutants: {data['survived_mutants']} 🛡️",
            f"🗡️ Killed Mutants: {data['killed_mutants']} 🗡️",
            f"🕒 Timeout Mutants: {data['timeout_mutants']} 🕒",
            f"🔥 Compile Error Mutants: {data['compile_error_mutants']} 🔥",
            f"💰 Total Cost: ${total_cost:.5f} USD 💰",
            f"\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n",
        ]
        return "\n".join(details)

    def _log_and_write(self, text: str) -> None:
        """
        将文本同时写入日志和文件
        
        Args:
            text: 要记录的文本内容
        """
        logger.info(text)
        with open(self.log_file, "a") as file:
            file.write(text + "\n")
