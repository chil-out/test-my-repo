"""
Module for generating prompts based on the programming language.
This module provides factory classes for creating different types of prompts used in test generation,
mutation testing, and YAML fixing operations.
"""

from importlib import resources

from jinja2 import Environment, FileSystemLoader


class TestGenerationPromptFactory:
    """Factory class for creating test generation prompts."""
    @staticmethod
    def get_prompt():
        return TestGenerationPrompt()


class TestGenerationPrompt:
    """Class containing templates for test generation prompts."""
    def __init__(self):
        # 创建Jinja2环境，用于加载和渲染模板
        env = Environment(
            loader=FileSystemLoader(
                resources.files(__package__).joinpath(
                    "templates",
                )
            )
        )
        # 加载分析器系统提示模板
        self.analyzer_system_prompt = env.get_template(
            "test_generation/analyzer_system.txt"
        )
        # 加载分析器用户提示模板
        self.analyzer_user_prompt = env.get_template(
            "test_generation/analyzer_user.txt"
        )
        # 加载测试生成器系统提示模板
        self.test_generator_system_prompt = env.get_template(
            "test_generation/test_generator_system.txt"
        )
        # 加载测试生成器用户提示模板
        self.test_generator_user_prompt = env.get_template(
            "test_generation/test_generator_user.txt"
        )


class TestGenerationWithMutationPromptFactory:
    """Factory class for creating test generation prompts that include mutation information."""
    @staticmethod
    def get_prompt():
        return TestGenerationWithMutationPrompt()


class TestGenerationWithMutationPrompt:
    """Class containing templates for test generation with mutation prompts."""
    def __init__(self):
        # 创建Jinja2环境，用于加载和渲染模板
        env = Environment(
            loader=FileSystemLoader(
                resources.files(__package__).joinpath(
                    "templates",
                )
            )
        )
        # 加载分析器系统提示模板
        self.analyzer_system_prompt = env.get_template(
            "test_generation/analyzer_system.txt"
        )
        # 加载分析器用户提示模板
        self.analyzer_user_prompt = env.get_template(
            "test_generation/analyzer_user.txt"
        )
        # 加载包含变异体的测试生成器系统提示模板
        self.test_generator_system_prompt = env.get_template(
            "test_generation/test_generator_with_mutants_system.txt"
        )
        # 加载包含变异体的测试生成器用户提示模板
        self.test_generator_user_prompt = env.get_template(
            "test_generation/test_generator_with_mutants_user.txt"
        )


class MutationTestingPromptFactory:
    """Factory class to generate prompts for mutation testing operations.
    Provides templates for analyzing code and generating mutants."""

    @staticmethod
    def get_prompt():
        return MutationTestingPrompt()


class MutationTestingPrompt:
    """Base prompt class containing system and user prompts for mutation testing.
    Includes templates for code analysis and mutant generation."""

    def __init__(self):
        # 创建Jinja2环境，用于加载和渲染模板
        env = Environment(
            loader=FileSystemLoader(
                resources.files(__package__).joinpath(
                    "templates",
                )
            )
        )
        # 加载变异测试分析器系统提示模板
        self.analyzer_system_prompt = env.get_template(
            "mutant_generation/analyzer_system.txt"
        )
        # 加载变异测试分析器用户提示模板
        self.analyzer_user_prompt = env.get_template(
            "mutant_generation/analyzer_user.txt"
        )
        # 加载变异器系统提示模板
        self.mutator_system_prompt = env.get_template(
            "mutant_generation/mutator_system.txt"
        )
        # 加载变异器用户提示模板
        self.mutator_user_prompt = env.get_template(
            "mutant_generation/mutator_user.txt"
        )


class YAMLFixerPromptFactory:
    """Factory class for creating YAML fixing prompts."""
    @staticmethod
    def get_prompt():
        return YAMLFixerPrompt()


class YAMLFixerPrompt:
    """Class containing templates for YAML fixing operations."""
    def __init__(self):
        # 创建Jinja2环境，用于加载和渲染模板
        env = Environment(
            loader=FileSystemLoader(
                resources.files(__package__).joinpath(
                    "templates",
                )
            )
        )
        # 加载YAML修复器用户提示模板
        self.yaml_fixer_user_prompt = env.get_template("utils/yaml_fixer_user.txt")
