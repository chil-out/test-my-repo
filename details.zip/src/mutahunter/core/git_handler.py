import subprocess
from typing import Any, Dict, List, Optional

from mutahunter.core.logger import logger


class GitCommandError(Exception):
    """Git命令执行错误的自定义异常类"""

    pass


class GitHandler:
    """Git操作处理类,提供获取修改文件和修改行号等功能"""
    
    def get_modified_files(covered_files) -> List[str]:
        """
        获取当前HEAD相比之前修改过的文件列表
        Args:
            covered_files: 已有测试覆盖的文件列表
        Returns:
            修改过且在测试覆盖范围内的文件路径列表
        """
        try:
            # 执行git diff命令获取修改的文件
            modified_files = GitHandler.run_git_command(
                ["git", "diff", "--name-only", "HEAD"]
            )
            # 过滤出在测试覆盖范围内的文件
            return [
                file_path for file_path in modified_files if file_path in covered_files
            ]
        except GitCommandError as e:
            logger.error(f"Error identifying modified files: {e}")
            return []

    @staticmethod
    def get_modified_lines(file_path: str) -> List[int]:
        """
        获取指定文件中被修改的行号列表
        Args:
            file_path: 文件路径
        Returns:
            修改过的行号列表
        """
        try:
            # 执行git diff获取文件的修改信息
            diff_output = GitHandler.run_git_command(
                ["git", "diff", "-U0", "HEAD", file_path]
            )
            return GitHandler._parse_diff_output(diff_output)
        except GitCommandError as e:
            logger.error(f"Error identifying modified lines in {file_path}: {e}")
            return []

    @staticmethod
    def run_git_command(command: List[str]) -> List[str]:
        """
        执行Git命令并返回输出结果
        Args:
            command: Git命令及其参数列表
        Returns:
            命令执行结果按行分割的列表
        Raises:
            GitCommandError: Git命令执行失败时抛出
        """
        try:
            output = subprocess.check_output(command, stderr=subprocess.PIPE)
            return output.decode("utf-8").splitlines()
        except subprocess.CalledProcessError as e:
            raise GitCommandError(f"Git command failed: {e.stderr.decode('utf-8')}")

    @staticmethod
    def _parse_diff_output(diff_output: List[str]) -> List[int]:
        """
        解析git diff命令的输出,提取修改的行号
        Args:
            diff_output: git diff命令的输出结果列表
        Returns:
            修改的行号列表
        """
        modified_lines = []
        for line in diff_output:
            # 解析diff输出中的@@行,获取修改的行号范围
            if line.startswith("@@"):
                line_numbers = line.split(" ")[2].split(",")
                start_line = int(line_numbers[0][1:])  # 去掉+号并转为整数
                line_count = int(line_numbers[1])  # 修改的行数
                modified_lines.extend(range(start_line, start_line + line_count))
        return modified_lines
