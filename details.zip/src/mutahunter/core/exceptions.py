class MutantSurvivedError(Exception):
    """变异体存活错误
    
    当变异体通过了所有测试用例时抛出此异常,
    表示测试套件未能检测到变异引入的缺陷
    """
    pass


class MutantKilledError(Exception):
    """变异体被杀死错误
    
    当变异体未通过测试用例时抛出此异常,
    表示测试套件成功检测到了变异引入的缺陷
    """
    pass


class CoverageAnalysisError(Exception):
    """覆盖率分析错误
    
    在分析测试覆盖率过程中出现错误时抛出此异常,
    可能是由于无法收集覆盖率数据或数据分析失败导致
    """
    pass


class MutationTestingError(Exception):
    """变异测试错误
    
    变异测试过程中的通用错误,可能由多种原因引起,
    如变异生成失败、测试执行异常等
    """
    pass


class ReportGenerationError(Exception):
    """报告生成错误
    
    在生成变异测试结果报告时出现错误时抛出此异常,
    可能是由于数据处理或格式化过程中的问题
    """
    pass


class UnexpectedTestResultError(Exception):
    """意外的测试结果错误
    
    当测试执行结果与预期不符时抛出此异常,
    例如测试过程中出现未预料的崩溃或超时
    """
    pass
