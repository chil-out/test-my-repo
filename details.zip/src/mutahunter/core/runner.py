import os
import shutil
import subprocess
from shlex import split


class MutantTestRunner:
    """变异测试运行器类,用于执行变异测试"""
    def __init__(self, test_command: str) -> None:
        # 初始化测试命令
        self.test_command = test_command

    def dry_run(self) -> None:
        """
        执行测试的预运行,确保在进行变异测试前所有测试都能通过。

        Raises:
            Exception: 如果在预运行过程中有任何测试失败。
        """
        result = self._run_test_command(self.test_command)
        if result.returncode != 0:
            raise Exception(
                "Tests failed. Please ensure all tests pass before running mutation testing."
            )

    def _run_test_command(self, test_command: str) -> subprocess.CompletedProcess:
        """
        在子进程中运行给定的测试命令。

        Args:
            test_command (str): 要运行的命令。

        Returns:
            subprocess.CompletedProcess: 命令执行的结果。
        """
        return subprocess.run(split(test_command), cwd=os.getcwd())

    def run_test(self, params: dict) -> subprocess.CompletedProcess:
        """运行变异测试,包括替换文件、执行测试和恢复文件的过程"""
        module_path = params["module_path"]  # 原始模块路径
        replacement_module_path = params["replacement_module_path"]  # 变异后的模块路径
        test_command = params["test_command"]  # 测试命令
        backup_path = f"{module_path}.bak"  # 备份文件路径
        try:
            # 替换原始文件为变异文件
            self.replace_file(module_path, replacement_module_path, backup_path)
            # 执行测试,设置30秒超时
            result = subprocess.run(
                split(test_command),
                text=True,
                capture_output=True,
                cwd=os.getcwd(),
                timeout=30,
            )
        except subprocess.TimeoutExpired:
            # 如果测试超时,认为变异体被杀死
            result = subprocess.CompletedProcess(
                test_command, 2, stdout="", stderr="TimeoutExpired"
            )
        finally:
            # 恢复原始文件
            self.revert_file(module_path, backup_path)
        return result

    def replace_file(self, original: str, replacement: str, backup: str) -> None:
        """
        备份原始文件并用替换文件替换它。
        
        Args:
            original: 原始文件路径
            replacement: 替换文件路径
            backup: 备份文件路径
        """
        if not os.path.exists(backup):
            shutil.copy2(original, backup)
        shutil.copy2(replacement, original)

    def revert_file(self, original: str, backup: str) -> None:
        """
        使用备份恢复原始文件。
        
        Args:
            original: 原始文件路径
            backup: 备份文件路径
        """
        if os.path.exists(backup):
            shutil.copy2(backup, original)
            os.remove(backup)
