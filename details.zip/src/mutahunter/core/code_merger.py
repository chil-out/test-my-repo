from grep_ast import filename_to_lang
from tree_sitter_languages import get_language, get_parser

from mutahunter.core.logger import logger
from mutahunter.core.utils import FileUtils


def merge_code(
    org_src_code: str,
    code_to_insert: str,
    indent_level: int,
    line_number: int,
) -> None:
    """
    合并代码片段到源代码中

    Args:
        org_src_code: 原始源代码字符串
        code_to_insert: 需要插入的代码片段
        indent_level: 目标缩进级别
        line_number: 插入的目标行号,如果为负数则追加到末尾

    Returns:
        str: 合并后的完整代码字符串
    """
    # 将源代码分割成行
    org_src_code_lines = org_src_code.splitlines()
    # 重置插入代码的缩进为0
    code_to_insert = reset_indentation(code_to_insert)
    # 调整插入代码到目标缩进级别
    code_to_insert = adjust_indentation(code_to_insert, indent_level)
    # 根据行号插入代码
    if line_number < 0:
        org_src_code_lines.append(code_to_insert)
    else:
        org_src_code_lines.insert(line_number, code_to_insert)
    # 合并所有行并返回
    modified_src_code = "\n".join(org_src_code_lines)
    return modified_src_code


def reset_indentation(code: str) -> str:
    """
    重置代码的缩进为0

    通过计算所有非空行的最小缩进量,然后将每行的缩进减去这个最小值,
    实现代码缩进的统一重置

    Args:
        code: 需要重置缩进的代码字符串

    Returns:
        str: 重置缩进后的代码字符串
    """
    lines = code.splitlines()
    if not lines:
        return code
    # 计算所有非空行的最小缩进数
    min_indent = min(len(line) - len(line.lstrip())
                     for line in lines if line.strip())
    # 对每行应用新的缩进
    return "\n".join(line[min_indent:] if line.strip() else line for line in lines)


def adjust_indentation(code: str, indent_level: int) -> str:
    """
    调整代码到指定的缩进级别

    为代码的每一行添加指定数量的空格作为缩进

    Args:
        code: 需要调整缩进的代码字符串
        indent_level: 目标缩进级别(空格数量)

    Returns:
        str: 调整缩进后的代码字符串
    """
    lines = code.splitlines()
    # 在每行前添加指定数量的空格
    adjusted_lines = [" " * indent_level + line for line in lines]
    return "\n".join(adjusted_lines)
