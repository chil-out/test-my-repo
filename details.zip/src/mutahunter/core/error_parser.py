import re


def extract_error_message(lang: str, fail_message: str) -> str:
    """
    根据不同编程语言提取错误信息
    
    Args:
        lang: 编程语言类型(python/java/go)
        fail_message: 包含错误信息的失败消息
        
    Returns:
        提取出的错误信息
    """
    if lang == "python":
        return extract_error_message_python(fail_message)
    elif lang == "java":
        return extract_error_message_java(fail_message)
    elif lang == "go":
        return extract_error_message_go(fail_message)
    else:
        return fail_message.strip()


def extract_error_message_python(fail_message):
    """
    从Python测试失败消息中提取错误信息
    
    使用正则表达式匹配 === FAILURES === 部分的内容
    如果提取的错误信息超过20行,只保留最后20行
    
    Args:
        fail_message: Python测试失败的完整消息
        
    Returns:
        提取出的错误信息,如果提取失败则返回原始消息
    """
    try:
        # 定义正则表达式匹配 === FAILURES === 部分
        MAX_LINES = 20
        pattern = r"={3,} FAILURES ={3,}(.*?)(={3,}|$)"
        match = re.search(pattern, fail_message, re.DOTALL)
        if match:
            err_str = match.group(1).strip("\n")
            err_str_lines = err_str.split("\n")
            if len(err_str_lines) > MAX_LINES:
                # 只显示最后MAX_LINES行
                err_str = "...\n" + "\n".join(err_str_lines[-MAX_LINES:])
            return err_str
        return fail_message.strip()
    except Exception as e:
        return fail_message.strip()


def extract_error_message_java(fail_message):
    """
    从Java Maven测试失败消息中提取错误信息
    
    使用正则表达式匹配 [ERROR] 开头到 FAILURE! 结尾的内容
    如果提取的错误信息超过20行,只保留最后20行
    
    Args:
        fail_message: Java Maven测试失败的完整消息
        
    Returns:
        提取出的错误信息,如果提取失败则返回原始消息
    """
    try:
        # 定义正则表达式匹配错误信息
        MAX_LINES = 20
        pattern = r"^\[ERROR\] (.*?FAILURE!)$"
        match = re.search(pattern, fail_message, re.MULTILINE | re.DOTALL)
        if match:
            err_str = match.group(1).strip("\n")
            err_str_lines = err_str.split("\n")
            if len(err_str_lines) > MAX_LINES:
                # 只显示最后MAX_LINES行
                err_str = "...\n" + "\n".join(err_str_lines[-MAX_LINES:])
            return err_str
        return fail_message.strip()
    except Exception as e:
        return fail_message.strip()


def extract_error_message_go(fail_message):
    """
    从Go测试失败消息中提取错误信息
    
    使用正则表达式匹配 --- FAIL: 开头的测试失败信息
    如果有多个失败测试用例,会提取所有失败信息
    如果提取的错误信息超过20行,只保留最后20行
    
    Args:
        fail_message: Go测试失败的完整消息
        
    Returns:
        提取出的错误信息,如果提取失败则返回原始消息
    """
    try:
        # 定义正则表达式匹配错误信息
        MAX_LINES = 20
        # 正则表达式匹配包含方法名的错误详情
        pattern = r"(?i)(--- FAIL: [^\n]*\n.*?)(?=\n\[|--- FAIL:|\Z)"
        matches = re.findall(pattern, fail_message, re.MULTILINE | re.DOTALL)

        if matches:
            err_str = ""
            for match in matches:
                err_str += match.strip("\n") + "\n"

            err_str_lines = err_str.split("\n")
            if len(err_str_lines) > MAX_LINES:
                # 只显示最后MAX_LINES行
                err_str = "...\n" + "\n".join(err_str_lines[-MAX_LINES:])
            return err_str.strip()
        return fail_message.strip()
    except Exception as e:
        return fail_message.strip()
