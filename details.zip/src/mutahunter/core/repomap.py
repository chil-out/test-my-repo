# 本文件基于Paul Gauthier的'aider'库,使用Apache-2.0许可证。
# 更多信息请参见 https://github.com/paul-gauthier/aider/blob/main/aider/repomap.py

# 导入所需的标准库
import os  # 操作系统相关功能
import warnings  # 警告控制
from collections import Counter, defaultdict, namedtuple  # 集合类型
from importlib import resources  # 资源管理
from pathlib import Path  # 路径操作
from typing import Any, Iterator, List, Optional, Set  # 类型注解

# 导入第三方依赖
import networkx as nx  # 图论算法库
from grep_ast import TreeContext, filename_to_lang  # AST解析工具
from litellm import token_counter  # Token计数器
from pygments.lexers import guess_lexer_for_filename  # 词法分析器
from pygments.token import Token  # Token类型定义
from pygments.util import ClassNotFound  # 异常类

# tree_sitter抛出FutureWarning,忽略此警告以避免干扰
warnings.simplefilter("ignore", category=FutureWarning)
from tree_sitter_languages import get_language, get_parser  # noqa: E402  # 代码解析器

# 定义Tag命名元组,用于存储代码标记信息
# rel_fname: 相对文件路径
# fname: 绝对文件路径
# line: 行号
# name: 标识符名称
# kind: 标记类型(定义/引用)
Tag = namedtuple("Tag", "rel_fname fname line name kind".split())


class RepoMap:
    """
    代码仓库映射类,用于分析和构建代码库的结构关系
    
    主要功能:
    1. 解析源代码文件,提取定义和引用信息
    2. 构建代码元素之间的关系图
    3. 使用PageRank算法对代码结构进行重要性排序
    4. 生成仓库的结构化映射表示
    """
    
    warned_files = set()  # 记录已经警告过的文件,避免重复警告

    def __init__(
        self,
        model: Optional[str] = None,  # 使用的语言模型名称
        root: None = None,  # 代码仓库根目录
        map_tokens: int = 1024,  # 最大token数量限制
        max_context_window: None = None,  # 最大上下文窗口大小
    ) -> None:
        """
        初始化RepoMap实例
        
        Args:
            model: 使用的语言模型名称,用于token计数
            root: 代码仓库根目录,默认为当前工作目录
            map_tokens: 生成的映射最大允许的token数量
            max_context_window: 上下文窗口的最大大小
        """
        if not root:
            root = os.getcwd()
        self.model = model
        self.root = root

        self.max_map_tokens = map_tokens
        self.max_context_window = max_context_window

    def token_count(self, string: str) -> int:
        """
        计算字符串的token数量
        
        Args:
            string: 需要计算token数的字符串
            
        Returns:
            int: token数量
        """
        if not string:
            return 0
        return token_counter(
            model=self.model, messages=[{"user": "role", "content": string}]
        )

    def get_repo_map(
        self,
        chat_files: List[Any],  # 聊天中涉及的文件列表
        other_files: List[str],  # 其他相关文件列表
        mentioned_fnames: None = None,  # 提到的文件名集合
        mentioned_idents: None = None,  # 提到的标识符集合
    ) -> str:
        """
        生成代码仓库的结构映射
        
        该方法会分析代码文件间的关系,生成一个结构化的仓库视图。
        当没有活跃的聊天文件时,会生成一个更大范围的仓库视图。
        
        Args:
            chat_files: 当前聊天涉及的文件列表
            other_files: 其他需要包含在映射中的文件
            mentioned_fnames: 在对话中提到的文件名集合
            mentioned_idents: 在对话中提到的标识符集合
        
        Returns:
            str: 仓库结构映射的字符串表示
        """
        if self.max_map_tokens <= 0:
            return
        if not other_files:
            return
        if not mentioned_fnames:
            mentioned_fnames = set()
        if not mentioned_idents:
            mentioned_idents = set()

        max_map_tokens = self.max_map_tokens

        # 当聊天中没有文件时,给出更大的仓库视图
        MUL = 16  # token数量倍增因子
        padding = 4096  # 预留的padding空间
        if max_map_tokens and self.max_context_window:
            # 计算目标token数,不超过上下文窗口大小
            target = min(max_map_tokens * MUL, self.max_context_window - padding)
        else:
            target = 0
        if not chat_files and self.max_context_window and target > 0:
            max_map_tokens = target

        try:
            # 获取排序后的标记映射
            files_listing = self.get_ranked_tags_map(
                chat_files,
                other_files,
                max_map_tokens,
                mentioned_fnames,
                mentioned_idents,
            )
        except RecursionError:
            # 处理递归错误,禁用映射生成
            self.max_map_tokens = 0
            return

        if not files_listing:
            return

        # 计算生成的映射的token数量
        self.token_count(files_listing)

        if chat_files:
            pass
        else:
            pass

        repo_content = ""
        repo_content += files_listing

        return repo_content

    def get_rel_fname(self, fname: str) -> str:
        """
        获取相对于仓库根目录的文件路径
        
        Args:
            fname: 文件的绝对路径
            
        Returns:
            str: 相对路径
        """
        return os.path.relpath(fname, self.root)

    def split_path(self, path):
        """
        分割文件路径,返回带冒号的路径列表
        
        Args:
            path: 文件路径
            
        Returns:
            List[str]: 处理后的路径列表
        """
        path = os.path.relpath(path, self.root)
        return [path + ":"]

    def get_mtime(self, fname: str) -> float:
        """
        获取文件的最后修改时间
        
        Args:
            fname: 文件路径
            
        Returns:
            float: 文件的修改时间戳,文件不存在时返回None
        """
        try:
            return os.path.getmtime(fname)
        except FileNotFoundError:
            pass

    def get_tags(self, fname: str, rel_fname: str) -> List[Tag]:
        """
        获取文件中的代码标记
        
        该方法会检查文件是否存在和可访问,然后提取其中的代码标记
        
        Args:
            fname: 文件的绝对路径
            rel_fname: 文件的相对路径
            
        Returns:
            List[Tag]: 代码标记列表
        """
        file_mtime = self.get_mtime(fname)
        if file_mtime is None:
            return []

        data = list(self.get_tags_raw(fname, rel_fname))
        return data

    def get_tags_raw(self, fname: str, rel_fname: str) -> Iterator[Tag]:
        """
        从源文件中提取原始代码标记
        
        该方法使用tree-sitter解析源代码,提取定义和引用信息。
        如果tree-sitter无法提取引用信息,会使用pygments作为备选方案。
        
        Args:
            fname: 文件的绝对路径
            rel_fname: 文件的相对路径
            
        Returns:
            Iterator[Tag]: 代码标记迭代器
        """
        # 获取文件对应的编程语言
        lang = filename_to_lang(fname)
        if not lang:
            return

        # 初始化解析器
        language = get_language(lang)
        parser = get_parser(lang)

        # 加载标记查询规则
        try:
            scm_fname = resources.files(__package__).joinpath(
                "queries", f"tree-sitter-{lang}-tags.scm"
            )
        except KeyError:
            return
        query_scm = scm_fname
        if not query_scm.exists():
            return
        query_scm = query_scm.read_text()

        # 读取并解析源代码
        with open(fname, "r", encoding="utf-8") as f:
            code = f.read()
        if not code:
            return
        tree = parser.parse(bytes(code, "utf-8"))

        # 执行标记查询
        query = language.query(query_scm)
        captures = query.captures(tree.root_node)

        captures = list(captures)

        # 处理查询结果
        saw = set()
        for node, tag in captures:
            if tag.startswith("name.definition."):
                kind = "def"  # 定义
            elif tag.startswith("name.reference."):
                kind = "ref"  # 引用
            else:
                continue

            saw.add(kind)

            result = Tag(
                rel_fname=rel_fname,
                fname=fname,
                name=node.text.decode("utf-8"),
                kind=kind,
                line=node.start_point[0],
            )

            yield result

        # 如果只找到定义没有引用,使用pygments补充引用信息
        if "ref" in saw:
            return
        if "def" not in saw:
            return

        try:
            lexer = guess_lexer_for_filename(fname, code)
        except ClassNotFound:
            return

        # 提取标识符token
        tokens = list(lexer.get_tokens(code))
        tokens = [token[1] for token in tokens if token[0] in Token.Name]

        # 生成引用标记
        for token in tokens:
            yield Tag(
                rel_fname=rel_fname,
                fname=fname,
                name=token,
                kind="ref",
                line=-1,
            )

    def get_ranked_tags(
        self,
        chat_fnames: List[Any],  # 聊天文件列表
        other_fnames: List[str],  # 其他文件列表
        mentioned_fnames: Set[Any],  # 提到的文件名集合
        mentioned_idents: Set[Any],  # 提到的标识符集合
    ) -> List[Tag]:
        """
        获取经过排序的代码标记
        
        该方法使用PageRank算法对代码定义和引用关系进行排序,
        考虑了文件的重要性和标识符的使用频率。
        
        Args:
            chat_fnames: 当前聊天涉及的文件列表
            other_fnames: 其他相关文件列表
            mentioned_fnames: 在对话中提到的文件名集合
            mentioned_idents: 在对话中提到的标识符集合
            
        Returns:
            List[Tag]: 排序后的代码标记列表
        """
        defines = defaultdict(set)  # 存储标识符的定义位置
        references = defaultdict(list)  # 存储标识符的引用位置
        definitions = defaultdict(set)  # 存储详细的定义信息
        personalization = dict()  # PageRank算法的个性化向量

        # 合并并排序所有文件
        fnames = set(chat_fnames).union(set(other_fnames))
        chat_rel_fnames = set()
        fnames = sorted(fnames)

        # 计算默认的个性化值
        personalize = 10 / len(fnames)

        # 处理每个文件
        for fname in fnames:
            # 检查文件是否存在且为普通文件
            if not Path(fname).is_file():
                if fname not in self.warned_files:
                    if Path(fname).exists():
                        raise Exception(
                            f"Repo-map can't include {fname}, it is not a file"
                        )
                    else:
                        raise Exception(
                            f"Repo-map can't include {fname}, it no longer exists"
                        )
                self.warned_files.add(fname)
                continue

            # 获取相对路径
            rel_fname = self.get_rel_fname(fname)

            # 设置个性化值
            if fname in chat_fnames:
                personalization[rel_fname] = personalize
                chat_rel_fnames.add(rel_fname)

            if fname in mentioned_fnames:
                personalization[rel_fname] = personalize

            # 获取文件中的标记
            tags = list(self.get_tags(fname, rel_fname))
            if tags is None:
                continue

            # 处理每个标记
            for tag in tags:
                if tag.kind == "def":
                    defines[tag.name].add(rel_fname)
                    key = (rel_fname, tag.name)
                    definitions[key].add(tag)

                if tag.kind == "ref":
                    references[tag.name].append(rel_fname)

        # 如果没有引用信息,使用定义作为引用
        if not references:
            references = dict((k, list(v)) for k, v in defines.items())
        
        # 获取同时存在定义和引用的标识符
        idents = set(defines.keys()).intersection(set(references.keys()))

        # 构建有向图
        G = nx.MultiDiGraph()

        # 添加边和权重
        for ident in idents:
            definers = defines[ident]
            # 提到的标识符权重更高
            if ident in mentioned_idents:
                mul = 10
            else:
                mul = 1
            # 根据引用次数添加边
            for referencer, num_refs in Counter(references[ident]).items():
                for definer in definers:
                    G.add_edge(referencer, definer, weight=mul * num_refs, ident=ident)

        if not references:
            pass

        # 设置PageRank参数
        if personalization:
            pers_args = dict(personalization=personalization, dangling=personalization)
        else:
            pers_args = dict()

        # 计算PageRank
        try:
            ranked = nx.pagerank(G, weight="weight", **pers_args)
        except ZeroDivisionError:
            return []

        # 计算每个定义的排名
        ranked_definitions = defaultdict(float)
        for src in G.nodes:
            src_rank = ranked[src]
            # 计算出边总权重
            total_weight = sum(
                data["weight"] for _src, _dst, data in G.out_edges(src, data=True)
            )
            # 分配排名值
            for _src, dst, data in G.out_edges(src, data=True):
                data["rank"] = src_rank * data["weight"] / total_weight
                ident = data["ident"]
                ranked_definitions[(dst, ident)] += data["rank"]

        ranked_tags = []
        # 按排名降序排序
        ranked_definitions = sorted(
            ranked_definitions.items(), reverse=True, key=lambda x: x[1]
        )

        # 收集排序后的标记
        for (fname, ident), rank in ranked_definitions:
            if fname in chat_rel_fnames:
                continue
            ranked_tags += list(definitions.get((fname, ident), []))

        # 如果没有排序的标记,包含所有其他文件的标记
        if not ranked_tags:
            for fname in other_fnames:
                rel_fname = self.get_rel_fname(fname)
                tags = self.get_tags(fname, rel_fname)
                for tag in tags:
                    ranked_tags.append(tag)

        return ranked_tags

    def get_ranked_tags_map(
        self,
        chat_fnames: List[Any],  # 聊天文件列表
        other_fnames: Optional[List[str]] = None,  # 其他文件列表
        max_map_tokens: Optional[int] = None,  # 最大token数量
        mentioned_fnames: Optional[Set[Any]] = None,  # 提到的文件名集合
        mentioned_idents: Optional[Set[Any]] = None,  # 提到的标识符集合
    ) -> str:
        """
        生成排序后的标记映射
        
        该方法使用二分查找确定最佳的标记数量,以适应token限制。
        它会在保持token数量限制的同时,尽可能包含更多的重要标记。
        
        Args:
            chat_fnames: 当前聊天涉及的文件列表
            other_fnames: 其他需要包含的文件列表
            max_map_tokens: 最大允许的token数量
            mentioned_fnames: 在对话中提到的文件名集合
            mentioned_idents: 在对话中提到的标识符集合
            
        Returns:
            str: 生成的标记映射字符串
        """
        # 初始化默认值
        if not other_fnames:
            other_fnames = list()
        if not max_map_tokens:
            max_map_tokens = self.max_map_tokens
        if not mentioned_fnames:
            mentioned_fnames = set()
        if not mentioned_idents:
            mentioned_idents = set()

        # 获取排序后的标记
        ranked_tags = self.get_ranked_tags(
            chat_fnames, other_fnames, mentioned_fnames, mentioned_idents
        )

        # 二分查找最佳标记数量
        num_tags = len(ranked_tags)
        lower_bound = 0
        upper_bound = num_tags
        best_tree = None
        best_tree_tokens = 0

        chat_rel_fnames = [self.get_rel_fname(fname) for fname in chat_fnames]

        # 对大型仓库使用较小的初始值
        middle = min(max_map_tokens // 25, num_tags)

        # 二分查找过程
        while lower_bound <= upper_bound:
            # 生成当前数量标记的树
            tree = self.to_tree(ranked_tags[:middle], chat_rel_fnames)
            num_tokens = self.token_count(tree)

            # 更新最佳结果
            if num_tokens < max_map_tokens and num_tokens > best_tree_tokens:
                best_tree = tree
                best_tree_tokens = num_tokens

            # 调整搜索范围
            if num_tokens < max_map_tokens:
                lower_bound = middle + 1
            else:
                upper_bound = middle - 1

            middle = (lower_bound + upper_bound) // 2

        return best_tree

    def render_tree(self, abs_fname: str, rel_fname: str, lois: List[int]) -> str:
        """
        渲染文件树结构
        
        将文件内容转换为树形结构的文本表示,重点显示感兴趣的行。
        
        Args:
            abs_fname: 文件的绝对路径
            rel_fname: 文件的相对路径
            lois: 感兴趣的行号列表
            
        Returns:
            str: 渲染后的树形结构文本
        """
        key = (rel_fname, tuple(sorted(lois)))

        # 读取文件内容
        with open(abs_fname, "r", encoding="utf-8") as f:
            code = f.read() or ""

        # 确保文件以换行符结束
        if not code.endswith("\n"):
            code += "\n"

        # 创建树上下文
        context = TreeContext(
            rel_fname,
            code,
            color=False,  # 不使用颜色
            line_number=False,  # 不显示行号
            child_context=False,  # 不显示子上下文
            last_line=False,  # 不显示最后一行
            margin=0,  # 无边距
            mark_lois=False,  # 不标记感兴趣的行
            loi_pad=0,  # 无行间距
            show_top_of_file_parent_scope=False,  # 不显示文件顶部作用域
        )

        # 添加感兴趣的行和上下文
        context.add_lines_of_interest(lois)
        context.add_context()
        res = context.format()
        return res

    def to_tree(self, tags: List[Tag], chat_rel_fnames: List[Any]) -> str:
        """
        将标记转换为树形结构的字符串表示
        
        该方法将代码标记组织成层次结构,并生成易于阅读的文本表示。
        
        Args:
            tags: 代码标记列表
            chat_rel_fnames: 聊天相关的文件相对路径列表
            
        Returns:
            str: 树形结构的文本表示
        """
        if not tags:
            return ""

        # 过滤掉聊天文件的标记
        tags = [tag for tag in tags if tag[0] not in chat_rel_fnames]
        tags = sorted(tags)

        cur_fname = None  # 当前处理的文件名
        cur_abs_fname = None  # 当前文件的绝对路径
        lois = None  # 感兴趣的行号列表
        output = ""  # 输出字符串

        # 添加一个虚拟标记以处理最后一个真实条目
        dummy_tag = (None,)
        for tag in tags + [dummy_tag]:
            this_rel_fname = tag[0]

            # 处理文件切换
            if this_rel_fname != cur_fname:
                if lois is not None:
                    output += "\n"
                    output += cur_fname + ":\n"
                    output += self.render_tree(cur_abs_fname, cur_fname, lois)
                    lois = None
                elif cur_fname:
                    output += "\n" + cur_fname + "\n"
                if type(tag) is Tag:
                    lois = []
                    cur_abs_fname = tag.fname
                cur_fname = this_rel_fname

            # 收集感兴趣的行号
            if lois is not None:
                lois.append(tag.line)

        # 截断长行,避免minified js等极端情况
        output = "\n".join([line[:100] for line in output.splitlines()]) + "\n"

        return output
