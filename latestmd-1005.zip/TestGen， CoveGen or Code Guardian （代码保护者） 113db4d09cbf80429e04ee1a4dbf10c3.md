# TestGen， CoveGen or Code Guardian （代码保护者）

- TODO
    - [ ]  readme 文档，怎么用
    - [ ]  精益画布
    - [ ]  ppt
    - [ ]  landingpage

![unit test user statement.webp](TestGen%EF%BC%8C%20CoveGen%20or%20Code%20Guardian%20%EF%BC%88%E4%BB%A3%E7%A0%81%E4%BF%9D%E6%8A%A4%E8%80%85%EF%BC%89%20113db4d09cbf80429e04ee1a4dbf10c3/unit_test_user_statement.webp)

# **User Statement**

| As a
 | software developer
 |
| --- | --- |
| I want to
 | write good unit tests for my code
 |
| But
 | it is time consuming and boring, so I end up postponing it.
 |
| TestPilot helps by
 | suggesting readable unit tests based on my code and documentation
 |
| **Unlike** | other test generators that focus on coverage and produce tests that are hard to understand.
 |

## **Current Unit Tests Development Methods**

- **Manual unit test development** – the traditional way of writing a unit test. Developer will be analysing the code which is to be tested and decide the testing framework and cover all the code flows of the code by writing the whole unit test along with mocks. This some tiresome process because it takes almost 30% of the developer’s time.
- **AI Based testing(co-pilot)** – GitHub’s Copilot is an advanced AI-driven tool designed to assist developers in writing code effortlessly. By simply commenting on what is to be implemented or taking a brief pause, Copilot intelligently suggests the appropriate code snippets. This functionality extends to the generation of unit tests as well.

## **What can be better?**

- Generate all the unit tests for complete applications or files without much human interaction.
- Cover major edge cases.
- Provide almost 80-90% coverage with ease.
- Validate all the tests that are generated automatically.
- Don’t repeat unit tests

Well, using the current unit testing methods we cannot achieve it. We need proper design and utilise the complete power of AI to achieve it.

![image.png](TestGen%EF%BC%8C%20CoveGen%20or%20Code%20Guardian%20%EF%BC%88%E4%BB%A3%E7%A0%81%E4%BF%9D%E6%8A%A4%E8%80%85%EF%BC%89%20113db4d09cbf80429e04ee1a4dbf10c3/image.png)

# 为什么不想写单元测试？

1. 单元测试麻烦，是负担
2. 着急上线，我没时间写单元测试
3. 我不会写单元测试

# 为什么要写单元测试？

1. 提高开发的效率
    1. 体现在调试代码，验证部分逻辑， 如果你每次都要打开浏览器终端，然后通过添加debug，或者打上断点来调试你的方法，有时候你不得不依赖一个环境，甚至一些没必要的前置条件。
    2. 有了单元测试，你其实可以不用打开应用来调试代码，验证逻辑，这本身就是提高开发效率的一种方法。
2. 提高代码质量和可靠性
    1. 减少bug和错误的发生率,  比如新增功能，或者改一个bug，你怎么能确定不影响老的代码？如果有了完整的单元测试，反而让你对你的改动更加自信。
    2. 促进代码重构和优化,  项目里是不是有很多老代码，你不敢重构？你宁可重写，也不想重构，为什么，你怕改坏了，看起来不合理的代码或者判断逻辑，你不敢轻易的删除
    3. 代码review， 你如何保证其他人的改动不会影响其他功能。
3. 文档
    1. 单元测试本身就是一种活文档，理论上你只需要看懂单元测试，你就能理解代码的逻辑
4. 改善程序设计
    1. 需要测试private方法吗？
    2. 我的项目设计的合理吗？
    3. 单一职责，高内聚低耦合吗？
5. 降低成本
    1. 技术债
6. 合作

---

1. Improve Development Efficiency
    1. This is reflected in debugging code and validating logic. If you have to open the browser console every time, add debug statements, or set breakpoints to debug your methods, sometimes you have to rely on an environment or even unnecessary prerequisites.
    2. 2. With unit tests, you can actually validate logic without having to open the application for debugging, which is itself a way to improve development efficiency.
2.  Improve Code Quality and Reliability
    1.  Reduce the occurrence of bugs and errors. For instance, when adding a new feature or fixing a bug, how can you ensure that it won’t affect existing code? With comprehensive unit tests, you can be more confident in your changes.
    2. Promote code refactoring and optimization. Are there many old codes in the project that you're afraid to refactor? Would you rather rewrite than refactor? Why? Because you're afraid of breaking things; you might hesitate to delete seemingly unreasonable code or logic.
    3.  Code reviews: How do you ensure that changes made by others won’t affect other functionalities.
3. Documentation
    1. Unit tests themselves serve as a living document. In theory, if you can understand the unit tests, you can grasp the logic of the code.
4. Improve Technical and Architecture Design
    1. Do we need to test private methods?
    2. Is the design of my project reasonable?
    3. Does it adhere to the principles of single responsibility, high cohesion, and low coupling
5. Reduce Costs
    1. Technical debt
6.  Collaboration

# TestGen CoveGen Code Guardian TestGenie

> ⚠️ Note: This project is under active development and may have incomplete features or changes, currently only support javascript/typescript language.
> 

**📌 Introduction**

An AI-powered Unit Test Generation and Code Coverage Enhancement solution that utilizes cutting-edge artificial intelligence to help developers quickly generate reliable unit tests at scale — locally and in CI.

CoveGen will also analyze the existing unit tests in your codebase, If any of these tests are problematic, CoveGen will assist you in fixing them.  Additionally, if test coverage falls below 80%, it will automatically enhance your unit tests to improve coverage.  All of this is done automatically.

---

# **What can** CoveGen **do?**

1. 生成新的单元测试/generate new unit test base on source code or source code folder
2. 修改错误的单元测试/ fix failure unit test base on existing unit test or running in source folder
3. 基于现有的单元测试，生成新的单元测试，提高测试覆盖率/ Generate new unit test to improve test coverage base on existing unit test

**✨ Key Features** 

- 可本地安装运行，也可以集成到到CI, 甚至可以集成到每个Merge Request中
- 支持本地自定义配置API Key, model，baseURL
- Custom AI models (compatible with OpenAI capabilities)
- 支持自定义测试命令
- 支持React/Vue/Angualar, Nodejs,Typescript,Javascript.
- 支持Vitest/Jest/Mocha/Jasmine主流框架
- 根据指定的源代码文件生成新的单元测试
- 根据指定的单元测试文件增强测试覆盖率到80%
- 指定源代码文件夹批量分析源代码文件和测试文件，自动创建新的单元测试，或者根据当前的测试文件提高测试覆盖率

```mermaid
flowchart TD
    A["开始"] --> B["CoveGen Processing"]
    B --> C["大模型分析代码"]
    C --> D{"是否理解代码结构以及参数是否正确?"}
    D -- 是 --> E["生成测试用例"]
    D -- 否 --> F["请求更多上下文信息"]
    F --> B
    E --> G["生成单元测试代码"]
    G --> H["执行测试"]
    H --> I{"测试通过?"}
    I -- 是 --> J["检查是否达测试覆盖率"]
    I -- 否 --> K["分析失败原因"]
    K --> L["优化测试用例"]
    L --> G
    J -- 是 --> 结束
    J -- 否 --> K
   
```

这个流程图展示了利用大模型自动生成前端单元测试的主要步骤：

1. 开始流程
2. 大模型分析代码结构
3. 如果理解代码结构，则生成测试用例；否则请求更多信息
4. 生成单元测试代码
5. 执行测试
6. 如果测试通过，检查新生成的单元测试覆盖率是否达标
7. 测试覆盖率达标则完成流程；否则分析失败原因并优化测试用例
8. 重复生成和执行测试，直到测试通过

---

# **Installation and Usage**

### **Requirements**

CoveGen no matter works with CLI mode or CI or MR mode, it requires OPENAI compatible LLM Provider such as R2D2, You need to add your R2D2 Token and R2D2 Model in your environment variables, or you can integrate Helix CLI to get your H2M token.

so before you begin, make sure you have the following:

**Add R2D2 Token or R2D2 Token Provider, config**`R2D2_TOKEN` or `R2D2_TOKEN_PROVIDER` set in your environment variables, which is required for calling the OpenAI API via R2D2.

### **Installation**

1. **Installing from NPM package**

> CoveGen requires Node.js v18 or later.
> 

```bash
npm install -g @bin.ma/cove-gen
```

1. **Installing from source**

```bash
git clone ...
npm install
npm run build
npm link
```

### **Configuration**

- Config with CLI
    
    ```bash
    cove-gen config set R2D2_TOKEN=<your token>
    or
    cove-gen config set R2D2_TOKEN_PROVIDER=<your token provider url>
    cove-gen config set MODEL=gpt-4-UAT
    ```
    
- **Config UI**

To use a more visual interface to view and set config options you can type:

```bash
cove-gen config
```

To get an interactive UI like below:

```bash
◆  Set config:
│  ○ OpenAI Key
│  ○ OpenAI API Endpoint
│  ○ R2D2 Token
│  ○ R2D2 Token Provider
│  ● Model (gpt-4o)
│  ○ Done
└
```

### **Additional configs**

- **Upgrading**
    
    Check and update the installed version with:
    
    ```bash
    cove-gen --version
    cove-gen update
    ```
    
    Or manually update with:
    
    ```bash
    npm update -g @bin.ma/cove-gen
    ```
    

More configs.

```bash
cove-gen --help
```

```bash

Usage:
  cove-gen [flags...]
  cove-gen <command>

Commands:
  config        Configure the CLI
  update        Update Micro Agent to the latest version

Flags:
  -h, --help                      Show help
  -m, --max-runs <number>         The maximum number of runs to attempt
  -p, --prompt <string>           Prompt to run
  -t, --test <string>             The test script to run
  -f, --test-file <string>        The test file to run
  -v, --visual <string>           Visual matching URL
      --thread <string>           Thread ID to resume
      --version                   Show version
```

## **Usage**

### **Manually Running in Local**

- Running with CLI mode
    - specific only one file
        
        ```bash
        cove-gen -f path-to-test-source-code -t npx vitest run 
        ```
        
    - running in folder mode
        
        ```bash
        cove-gen -dir src/source-folder-name
        
        ```
        
- Running with Configuration Mode
    
    Add cove-gen configuration file in your codebase.
    
    create new covegen.config.json, configure the configuration file with the commands.
    
    - specific unit test file
        
        ```json
        {
        	testCommandDir: "src/source-folder-name"
        }
        ```
        
    - running in folder mode
        
        ```json
        {
        	testCommandDir: "src/source-folder-name"
        }
        ```
        

### **Integration with Bitbucket**

- [ ]  TODO

### **Integration CI with Lightspeed**

- [ ]  TODO

---

# **Roadmap**

Below is the roadmap of planned features, with the current implementation status:

- [x]  Automatically generates unit tests for your software projects, utilizing advanced AI models to ensure comprehensive test coverage and quality assurance. (similar to Meta)
    - [x]  Check test flakiness, e.g. by running 5 times as suggested by TestGen-LLM
    - [ ]  Being able to generate tests for different programming languages
    - [ ]  Being able to deal with a large variety of testing scenarios
    - [ ]  Generate a behavior analysis for the code under test, and generate tests accordingly
- [ ]  Cover more test generation pains
    - [ ]  Generate new tests that are focused on the PR changes
    - [ ]  Run over an entire repo/code-base and attempt to enhance all existing test suites
- [ ]  Improve usability
    - [ ]  Connectors for GitHub Actions, Jenkins, CircleCI, Travis CI, and more
    - [ ]  Integrate into databases, APIs, OpenTelemetry and other sources of data to extract relevant i/o for the test generation
    - [ ]  Add a setting file

# **Contributing**

Suggestions and code contributions are welcome! Please check our contribution guidelines.

---

**References:**

https://www.freecodecamp.org/news/automated-unit-testing-with-testgen-llm-and-cover-agent/

[https://keploy.io/blog/technology/revolutionising-unit-test-generation-with-llms](https://keploy.io/blog/technology/revolutionising-unit-test-generation-with-llms)

# Limitation

- Can’t install package automatically

---

# **FAQ’s**

### **What are the current limitations of unit test generation with AI?**

Currently, AI based unit test generators, cannot independently decide on or install mocking libraries, nor can they handle the full complexity of creating unit tests from scratch. Additionally, the cost associated with using LLMs increases with the number of tokens processed. Achieving the final 10% of test coverage remains particularly difficult for LLMs, despite significant improvements in initial coverage.

### **How does the proposed AI unit test generation design work?**

The proposed design involves using LLMs to generate candidate test cases, which are then pre-processed and integrated into the build system. The remaining tests are validated for increased code coverage and reliability. The process includes analyzing the code, generating and integrating test cases, and running multiple iterations to ensure robustness and eliminate flaky tests.

### **What is the role of LLMs in the automated unit test generation process?**

LLMs analyze the provided source code to generate candidate test cases aimed at covering various code paths and edge cases and try to enhance the unit test generation process by suggesting tests that can increase code coverage, thereby reducing the manual effort required from developers.

### **What are the benefits of using AI unit test generation compared to traditional manual methods?**

AI based unit test generation significantly reduces the time and effort required from developers by automating the creation of unit tests. This allows developers to focus on more complex and value-adding tasks. Additionally, the proposed design promises high coverage and reliability with minimal human intervention, thus improving the efficiency and effectiveness of the testing process.

### **Does it work in practice?**

In progress.

---

[精益画布](https://www.notion.so/155de54e03b84eebb105c9497228610e?pvs=21)