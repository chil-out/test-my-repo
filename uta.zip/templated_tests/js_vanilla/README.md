# Vanilla Javascript Application Example
A simple vanilla js project to find github users and their repositories.

## Requirements
```
npm install
```

## How to run
`cd` into this directory and run:

```
npm run test:coverage
```

The coverage report will be generated as `coverage.xml` and the results will be printed in the shell as well.
