#ifndef CALCULATOR_HPP
#define CALCULATOR_HPP

#include <string>

double calculate(double op1, double op2, const std::string& operation);

#endif // CALCULATOR_HPP
